# Split Personality Evolution — standalone TAP

Load `split-personality-evolution.tap` using the normal TS2068 / TS-Pico TAP workflow. It starts automatically. **Press and release Q or Enter to return to BASIC.** It does not require a DCK cartridge, replacement ROM, extra RAM, or TSPico bank configuration.

This is a new 48K RAM implementation of the original animation, retaining its artwork and 101 stage shapes:

1. ECM picture.
2. A vertical resolution boundary moves left to reveal yellow/blue highres.
3. The boundary becomes diagonal.
4. The diagonal becomes a sine wave.
5. The sine wave moves.
6. The display resolves into four quadrants: green-border ECM at upper left, yellow/blue highres at upper right, green/magenta highres at lower left, and red-border ECM at lower right.
7. After the final hold and brief black reload, the sequence repeats.

The two images remain stationary. The program changes display mode at each row's dividing point and supplies the correct bitmap/attribute interpretation on each side. These are genuine highres and ECM port-FF modes. The unwanted alternate hires columns are not used as an approximation.

## Speed tradeoff

Screen scanout remains precisely synchronized at the native refresh rate, but the **animation steps are slower than the banked cartridge**. The next transition is prepared while the current stage remains visible. A complete loop takes approximately **2½ minutes**. This is the cost of this implementation's self-contained standard-RAM operation; it is not an exact timing reproduction of the cartridge.

Visible transitions are committed together during the interval between two active frames. Preparation does not sweep mismatched artwork or a partly updated boundary down the screen. At a zero-width first region, the whole row uses the other mode, including its left border.

## Memory and raster approach

The original duplicates each 128-lowres-pixel / 256-hires-pixel panel horizontally. The builder verifies those duplicate bytes and stores each half only once. The two independent images therefore occupy 12KB in total, without changing their displayed contents.

The large banked unrolled raster is replaced by one shared 224-T-state scanline routine. SP streams an AF value and two return targets for each row. RET enters the appropriate point in a NOP delay field; OUTI supplies the second mode from a separate table. Two parameter buffers let the visible display remain unchanged while the next stage is prepared.

Each stage's column positions are stored with PackBits compression. During preparation, source pixels and attributes are assembled into a maximum 256-record patch buffer. At commit, up to 112 records are written after active scanout; the remaining records are written in the next frame's top blanking. Parameters switch before the first active pixel. The patch loop costs 55T per record except for its final iteration; the top delay compensates for the remainder count. Border updates are synchronized and FE's sound bits remain clear.

The program saves 0x5B00–0x7FFF before using BASIC's workspace. Its IM2 vector table and RET handler reside in that saved workspace. Exit restores the saved BASIC bytes, main/alternate registers, IX/IY, I and stack, selects normal display/mapping and IM1, then returns to the BASIC loader. BASIC clears the screen, prints `Q/ENTER: DEMO FINISHED`, and reports `0 OK`. Load the TAP file afresh for another run.

## Verification

The TAP was loaded through the stock TS2068 HOME/EXROM loader in unmodified TSRun, not simply injected into RAM. The main test checked **17,965 frames**, including two complete loops and every one of the 101 stages. It compared **2,756,659,200 visible pixels**, including borders, with independent source-image/mode calculations: **zero mismatches**. Every row's two mode writes were checked for the exact value and I/O-cycle time. Reset frames were checked for a black active screen.

Q and Enter both restored the BASIC return address, saved workspace, saved registers, stack and normal mode. Additional exit tests used the moving sine-wave stage and the four-quadrant finale. The worst measured preparation-row operation was 6,061 T-states and fits its assigned blanking window. The native emulator modules are pinned to commit 41dbe3e41c692a1806f2cb900c5a0faa1549ae77.

Physical TS2068 / TS-Pico loading and timing have not been tested here. The included preview GIF is a **condensed selection of actual emulator frames**, not a real-time recording of the longer native sequence.

## Rebuild

The source archive includes the builders, original art and stage data, pinned emulator modules and tests. It excludes full system ROM images. Building the TAP needs only Python 3's standard library:

```sh
python3 tap-suite/build_evolution.py
```

Full loader and pixel verification additionally requires Node.js and stock ROM fixtures. Supply the ROMs at the paths used by the test, or use the optional public-repository fixture helper:

```sh
python3 tap-suite/fetch_test_roms.py
node tap-suite/test_evolution.mjs
```

`QUICK=1 node tap-suite/test_evolution.mjs` checks timing, stages, loops and exits while skipping pixel comparisons. `CALIBRATE=1` measures the two dispatch constants for the supplied core. Neither option is used to claim the full pixel result. Reports for the full pixel run and the additional late-stage exit run are supplied separately.
