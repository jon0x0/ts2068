"""Link trench media to the hardware-working RAM512 R3 player."""
from pathlib import Path
import json
O=Path('build/trench2');m=json.loads((O/'manifest.json').read_text())
s=Path('src/ram512c_player.asm').read_text().replace("'RVF000.TAP'","'SCF000.TAP'")
s=s.replace("'TSPICO 512K RAM VIDEO R3'","'STAR WARS COLOUR DETAIL 2'").replace('RAM VIDEO R3 ERROR','TRENCH VIDEO ERROR')
a=s.index('help: db ');b=s.index('volume_text:',a)
lines=["help: db 'SOURCE 44.5 TO 52.0 SECONDS',13"]
for i,tag in enumerate(('F','W'),1):
 p=m['profiles'][tag];w=p['width'];h=p['height'];fps=p['fps_target'];n=p['source_frames']
 lines+=[f"      db '{i} {w}X{h} ECM / {fps} FPS TARGET',13",f"      db '  {n} FRAMES / {n/fps:.2f} SEC LOOP',13"]
lines += ["      db 13,'COLOUR DETAIL V2 / 8X1 ECM',13", "      db 'PRELOADS AND VERIFIES 512K',13", "      db 'REPLACES SRAM CARTRIDGES',13", "      db 'AND RAM DISKS - THEN LOOPS',13,13", "      db 'X STOP  SPACE PAUSE / RESUME',13,0"]
s=s[:a]+'\n'.join(lines)+'\n'+s[b:]
Path('src/sc512_player.asm').write_text(s)
s=Path('scripts/build_ram512c_tap.py').read_text().replace('ram512c','sc512').replace('RV512C','SC512')
Path('scripts/build_sc512_tap.py').write_text(s)
for suffix in ('','_errors','_controls','_fuse','_fuse_words'):
 s=Path('scripts',f'test_ram512c{suffix}.py').read_text().replace('ram512c','sc512').replace('RV512C','SC512')
 s=s.replace('from test_sc512_bus import','from test_ram512c_bus import')
 s=s.replace("'build/sc512'","'build/trench2'").replace("B/'sc512'","B/'trench2'").replace("B/'ram512/F/","B/'trench2/F/")
 if suffix=='_errors':s=s.replace('RVF000.TAP','SCF000.TAP')
 Path('scripts',f'test_sc512{suffix}.py').write_text(s)
print('Created SC512 source and test entrypoints')
