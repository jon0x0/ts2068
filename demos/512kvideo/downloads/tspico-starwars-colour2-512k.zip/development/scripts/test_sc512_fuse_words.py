"""Real Fuse Z80 check of the fixed paired-word kernel, with a borrowed data stack."""
from pathlib import Path
import subprocess,json,hashlib,re,struct
from build import symbols
R=Path(__file__).resolve().parents[1];B=R/'build';s=symbols(B/'sc512.sym')
image=(B/'trench2/F/sram.bin').read_bytes();index=(B/'trench2/F/index.bin').read_bytes();page,block,n=struct.unpack('<BBH',index[:4]);payload=image[page*8192+256+block*256:page*8192+512+block*256]
cmd=[f"breakpoint {s['menu_key']} if z80:sp == 0xfff0",'commands 1','delete 1','set z80:iff1 0','set z80:iff2 0',f"set {s['IRQ_ALLOW']} 0"]
cmd += [f'set {0x8000+i} {v}' for i,v in enumerate(payload)]
cmd += [f"set {s['W_SOURCE']} 0",f"set {s['W_SOURCE']+1} 128",'set z80:sp 0xffee','set 0xffee 0','set 0xffef 127',f"set z80:pc {s['ram_words64']}",'continue','end','breakpoint 0x7f00','commands 2','print z80:sp',f"print [{s['W_SOURCE']}]+256*[{s['W_SOURCE']+1}]"]
expected=[0xfff0,0x8100];checks={}
for addr,value in struct.iter_unpack('<HH',payload):checks[addr]=value
for addr,value in sorted(checks.items()):cmd += [f'print [{addr}]+256*[{addr+1}]'];expected.append(value)
cmd += ['exit 0','end']
si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=subprocess.SW_HIDE
p=subprocess.run(['C:/Program Files (x86)/Fuse/fuse.exe','--machine','ts2068','--no-sound','--no-loading-sound','--no-autosave-settings','--speed','5000','--tape',str(B/'SC512.TAP'),'--auto-load','--debugger-command','\n'.join(cmd)],capture_output=True,text=True,timeout=45,startupinfo=si)
values=[int(v,16) for v in re.findall(r'^0x([0-9a-f]+)\s*$',p.stdout,re.M)]
assert p.returncode==0 and values==expected,(p.returncode,values,expected,p.stderr)
r=dict(passed=True,real_fuse_z80=True,paired_word_checks=len(checks),normal_stack_restored=True,source_advanced_256=True,image_sha256=hashlib.sha256((B/'sc512.bin').read_bytes()).hexdigest())
(B/'sc512-fuse-words-validation.json').write_text(json.dumps(r,indent=2)+'\n');print(r)
