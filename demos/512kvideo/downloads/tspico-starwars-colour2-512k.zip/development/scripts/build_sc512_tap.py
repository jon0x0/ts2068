"""Package the HOME-RAM player as ordinary auto-running BASIC + CODE TAP."""
from pathlib import Path
import json,struct,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'references/tspico-firmware-build/src/TS'))
from channels import TOKENS
from build_video_samples import tap_block
tokens={name:bytes([i+0xa5]) for i,name in enumerate(TOKENS)}
def kw(name):return tokens[name]+b' '
def val(n):return kw('VAL')+f'"{n}"'.encode()
def line(n,body):return struct.pack('>H',n)+struct.pack('<H',len(body)+1)+body+b'\r'
program=b''.join(line(n,b) for n,b in (
    (10,kw('CLEAR')+val(49151)),
    (20,kw('LOAD')+b'"" '+kw('CODE')),
    (30,kw('PAUSE')+val(60)), # allow the original handler to finish SD cleanup
    (40,kw('RANDOMIZE')+kw('USR')+val(57600)),
    (50,kw('STOP'))))
code=(ROOT/'build/sc512.bin').read_bytes()
assert len(code)<16384
header=bytes([0])+b'RAM VIDEO '.ljust(10,b' ')+struct.pack('<HHH',len(program),10,len(program))
code_header=bytes([3])+b'RAM PLAYER'.ljust(10,b' ')+struct.pack('<HHH',len(code),49152,0x8000)
tap=tap_block(0,header)+tap_block(255,program)+tap_block(0,code_header)+tap_block(255,code)
(ROOT/'build/SC512.TAP').write_bytes(tap)
print('SC512.TAP:',len(tap),'bytes; player:',len(code),'bytes')

