from test_video_menu_controls import verify
verify('sc512','trench2')
