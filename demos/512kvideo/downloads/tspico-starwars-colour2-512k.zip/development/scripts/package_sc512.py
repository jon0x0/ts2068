"""Hash-gated standalone release of the user's 512 KiB trench animation."""
from pathlib import Path
import hashlib,json,zipfile,struct,functools
R=Path(__file__).resolve().parents[1];B=R/'build';O=B/'trench2'
h=lambda b:hashlib.sha256(b).hexdigest()
image=(B/'sc512.bin').read_bytes();tape=(B/'SC512.TAP').read_bytes()
m=json.loads((O/'manifest.json').read_text());assert set(m['profiles'])=={'F','W'}
blocks=[];pos=0
while pos<len(tape):
 n=int.from_bytes(tape[pos:pos+2],'little');pos+=2;b=tape[pos:pos+n];pos+=n
 assert len(b)==n and not functools.reduce(int.__xor__,b,0);blocks.append(b)
assert len(blocks)==4 and blocks[3][1:-1]==image and int.from_bytes(blocks[2][14:16],'little')==0xc000
assert b'SCF000.TAP' in image and b'STAR WARS COLOUR DETAIL 2' in image
doc='''STAR WARS COLOUR DETAIL 2 / 512 KiB -- SC512.TAP

Stock TSPico firmware 1.00; HOME-RAM TAP player based on working RAM512 R3.
Uses all 512 KiB expansion SRAM. No firmware replacement or ROM routines.

INSTALL
Copy all 33 TAP files from this ZIP's TAP directory directly into the SD
card /TAP/ directory. Do not put them in a subdirectory for this demo.
They have distinct names and coexist with the earlier SW512 and RV512 demos:
 SC512.TAP                  player
 SCF000.TAP--SCF015.TAP      option 1 data
 SCW000.TAP--SCW015.TAP      option 2 data

Power reset the TS2068 and TSPico. From normal Flash-ROM startup enter:
 SAVE "tpi:cd /"
 LOAD "tpi:SC512.TAP"
 LOAD ""

MENU
'''
for i,tag in enumerate(('F','W'),1):
 p=m['profiles'][tag]
 assert f"{i} {p['width']}X{p['height']} ECM / {p['fps_target']} FPS TARGET".encode() in image
 doc+=f" {i}: {p['width']}x{p['height']} extended colour, {p['source_frames']} frames, {p['fps_target']} fps target.\n"
 doc+=f"    Nominal loop {p['playback_seconds']:.3f}s; useful SRAM {p['meaningful_bytes']:,} bytes.\n"
doc+='''
Both options use the complete supplied source interval 44.5--52.0 seconds.
The 12 fps option has 90 frames and exactly 7.5 seconds nominal playback.
The 15 fps option has 113 frames: covering 7.5s requires rounding to whole
frames, so the nominal loop is 7.533s. No intentional slow motion.
Widescreen proportions are preserved approximately to integer pixels,
with black borders in the 256x192 display. No audio.

Choose an option and wait for all SRAM to load and verify. The animation
then loops without SD file reads. Space pauses/resumes; X stops and shows
counters. After stopping, any key returns to the menu; choosing reloads SRAM.
Loading replaces all SRAM cartridges and RAM disks. Use normal Flash-based
startup, not a system depending on SRAM content that must be retained.

COLOUR AND CODEC
8x1 extended colour, gamma 1.06, fixed spatial Bayer dither.
Pixel-local colour confidence gives small coloured details extra weight,
selectively relaxes the neutral-colour penalty, and adds up to 10 percent
saturation where genuine colour is present. Neutral regions retain suppression.
The full-width option retains 256x108 at 12 fps; the 15 fps option uses 232x98
because the more colourful 240x102 version exceeded the SRAM budget.
Skin remains an approximation within the TS2068 palette; no peach/brown was added.
All chosen quantized frames are reconstructed exactly; no dropped cell
updates or deliberately distributed frame patches. The finite hardware
palette still requires spatial shading. No changes to the source file.
Paired 16-bit replacements prioritize fast decoding. MEMDOCK read priming,
LDIR copying, safe preload spacing and bounded diagnostics are retained.

VALIDATION
See validation/: full legacy protocol preload and byte comparison of all
512 KiB, final alias/checksum sweep, two exact playback loops per sample,
strict instruction execution without copy shortcuts, pause/stop/error tests,
and native Fuse startup/paired-word checks. The model includes access-driven
selector transitions and 50ms additional bank-response delay. Playback rates
are targets; this new clip has not yet been measured on physical hardware.
The underlying R3 player previously received a hardware playback success.

Previews use the existing TS2068 software palette and target timing; they
are not recordings of physical hardware. Development sources are included;
re-encoding requires the user's original MP4, which is not included.
'''
(R/'docs/STAR-WARS-512K-COLOUR2.txt').write_text(doc)
files={'TAP/SC512.TAP':tape,'START-HERE.txt':doc.encode(),'samples.json':(O/'manifest.json').read_bytes(),'previews.png':(O/'previews.png').read_bytes(),'colour-comparison.png':(O/'colour-comparison.png').read_bytes()}
for tag,p in m['profiles'].items():
 raw=(O/tag/'sram.bin').read_bytes();assert len(raw)==524288 and h(raw)==p['image_sha256']
 assert h((O/tag/'frames.ecm').read_bytes())==p['frames_sha256'] and p['all_frames_exact']
 for v in p['volumes']:
  data=(O/v['name']).read_bytes();assert h(data)==v['sha256'] and len(data)==v['bytes'];files['TAP/'+v['name']]=data
 name=f'{tag}-strict-validation.json';data=(O/name).read_bytes();d=json.loads(data)
 assert d['passed'] and d['loaded_through_legacy_protocol'] and not d['copy_shortcut'] and d['all_frames_exact'] and d['loops']>=2 and d['no_sd_file_reads_during_playback']
 assert d['image_sha256']==h(image) and d['sram_sha256']==p['image_sha256'] and d['samples_sha256']==h((O/'manifest.json').read_bytes())
 files['validation/'+name]=data
 files[f'SC{tag}-preview.mp4']=(O/f'SC{tag}-preview.mp4').read_bytes()
for name in ('controls-validation.json','errors-validation.json'):
 data=(O/name).read_bytes();d=json.loads(data);assert d['passed'] and d['image_sha256']==h(image);files['validation/'+name]=data
for name in ('sc512-fuse-validation.json','sc512-fuse-words-validation.json'):
 data=(B/name).read_bytes();d=json.loads(data);assert d['passed'] and d.get('image_sha256',d.get('player_sha256'))==h(image)
 if 'tape_sha256' in d:assert d['tape_sha256']==h(tape)
 files['validation/'+name]=data
for name in ('sc512_player.asm','ram512_words.inc','ram512_transport.inc','ram512b_files.inc','layout.inc','display.asm'):
 files['development/src/'+name]=(R/'src'/name).read_bytes()
for name in ('build_trench2_samples.py','trench_colour2.py','trench_quantizer.py','full160_v7_quantizer.py','preview_trench2.py','probe_trench2.py','create_sc512.py','build_sc512_tap.py','build_video_samples.py','build.py','test_sc512.py','test_sc512_controls.py','test_sc512_errors.py','test_sc512_fuse.py','test_sc512_fuse_words.py','test_ram512c_bus.py','package_sc512.py'):
 files['development/scripts/'+name]=(R/'scripts'/name).read_bytes()
for name in ('ram512_machine.py','test_cartridge.py','test_legacy.py'):files['development/tests/'+name]=(R/'tests'/name).read_bytes()
for path in (R/'references/TSVideoCodec-ram512').glob('*'):
 if path.is_file():files['development/references/TSVideoCodec-ram512/'+path.name]=path.read_bytes()
for name in ('sc512.bin','sc512.sym','sc512.lst','font.bin'):files['development/build/'+name]=(B/name).read_bytes()
files['manifest.json']=(json.dumps(dict(version='starwars-colour2-512k-v1',hardware_tested=False,player_sha256=h(image),source_quantizer_sha256=h((R/'scripts/trench_colour2.py').read_bytes()),files={n:h(d) for n,d in files.items()}),indent=2)+'\n').encode()
out=B/'tspico-starwars-colour2-512k.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for n,d in sorted(files.items()):z.writestr(n,d)
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for n,d in files.items():assert h(z.read(n))==h(d)
assert sum(n.startswith('TAP/') for n in files)==33
print(out,out.stat().st_size,'bytes; 33 TAP files')
