"""Pre-play bounds, page-write contracts, and transport error checks."""
import sys,json,struct,hashlib
from pathlib import Path
sys.path[:0]=['tests','scripts']
from ram512_machine import RamMachine,ROOT
from build_video_samples import code_pair
B=ROOT/'build';O=B/'trench';checks=0
m=RamMachine(name="sw512")
try:
 m.initialize();m.mem[0xa100:0xc000]=struct.pack('<HH',0x5800,0)*1984
 for address,valid in [(0x4000,True),(0x57fe,True),(0x6000,True),(0x77fe,True),(0x5800,True),(0x4001,False),(0x5802,False),(0x5b00,False),(0xe000,False),(0,False),(0x7800,False)]:
  m.mem[0xa100:0xa102]=struct.pack('<H',address)
  c=m.call('validate_page');assert bool(c.cf)!=valid,(hex(address),c.cf);checks+=1
 m.mem[m.syms['META']+7]=63;m.word('INDEX_END',0x7804)
 for page,block,count,valid in [(2,0,1,True),(63,30,1,True),(2,0,93,True),(1,0,1,False),(64,0,1,False),(2,31,1,False),(2,0,0,False),(2,0,94,False),(63,30,2,False),(2,1,93,False)]:
  m.mem[0x7800:0x7804]=struct.pack('<BBH',page,block,count)
  c=m.call('validate_index');assert bool(c.cf)!=valid,(page,block,count,c.cf);checks+=1
finally:m.pico.close()
meta=bytearray((O/'F/meta.bin').read_bytes());struct.pack_into('<H',meta,12,2000)
for bad_crc in (False,True):
 data=bytearray(code_pair('BAD META',meta if not bad_crc else (O/'F/meta.bin').read_bytes()))
 if bad_crc:data[-1]^=1
 m=RamMachine(name='sw512',files={'SWF000.TAP':bytes(data)})
 try:
  m.initialize();m.mem[m.syms['PROFILE']]=ord('F');before=bytes(m.mem[0x7800:0x7e00]);c=m.call('preload',max_steps=3000000)
  assert c.cf and not m.mem[m.syms['PLAY']]
  assert bytes(m.mem[0x7800:0x7e00])==before,'oversized index copied before length check'
  assert not any(m.sram),'SRAM touched before rejecting bad manifest'
  checks+=1
 finally:m.pico.close()
r=dict(passed=True,cases=checks,invalid_destinations_rejected=True,invalid_spans_rejected=True,oversized_index_rejected_before_copy=True,bad_checksum_stops_before_play=True,image_sha256=hashlib.sha256((B/'sw512.bin').read_bytes()).hexdigest())
(O/'errors-validation.json').write_text(json.dumps(r,indent=2)+'\n');print(r)
