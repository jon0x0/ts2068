"""Render exact encoded ECM frames using the established TS2068 preview palette."""
from pathlib import Path
import json,sys,subprocess
import numpy as np
from PIL import Image,ImageDraw
sys.path[:0]=['scripts','references/TSVideoCodec-ram512']
from full160_v7_quantizer import PALETTE
from svd_ecm import screen_offset
O=Path('build/trench');m=json.loads((O/'manifest.json').read_text())
offsets=np.array([[screen_offset(y,x) for x in range(32)] for y in range(192)])
def render(raw):
 bitmap=np.frombuffer(raw[:6144],dtype=np.uint8)[offsets]
 attrs=np.frombuffer(raw[6144:],dtype=np.uint8)[offsets]
 ink=(attrs&7)+((attrs>>6)&1)*8;paper=((attrs>>3)&7)+((attrs>>6)&1)*8
 bits=(bitmap[:,:,None]>>np.arange(7,-1,-1))&1
 return PALETTE[np.where(bits,ink[:,:,None],paper[:,:,None])].reshape(192,256,3)
sheet=Image.new('RGB',(1536,824),(24,24,24));draw=ImageDraw.Draw(sheet)
for tag,p in m['profiles'].items():
 raw=(O/tag/'frames.ecm').read_bytes();fps=p['fps_target']
 proc=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','256x192','-r',str(fps),'-i','pipe:0','-vf','scale=1024:768:flags=neighbor','-an','-c:v','libx264','-crf','16','-pix_fmt','yuv420p',str(O/f'SW{tag}-preview.mp4')],stdin=subprocess.PIPE)
 for i in range(p['source_frames']):proc.stdin.write(render(raw[i*12288:(i+1)*12288]).tobytes())
 proc.stdin.close();assert proc.wait()==0
 if tag=='F':
  for j,t in enumerate((0,1.5,2.5,4.5,6,7)):
   i=round(t*fps);im=Image.fromarray(render(raw[i*12288:(i+1)*12288])).resize((512,384),Image.Resampling.NEAREST)
   x=(j%3)*512;y=(j//3)*412;sheet.paste(im,(x,y+28));draw.text((x+8,y+8),f'{44.5+i/fps:.2f}s - encoded 256x108 ECM',fill='white')
sheet.save(O/'previews.png');print('Rendered both previews and contact sheet')
