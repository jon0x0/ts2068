"""Apply the same safe menu/quit controls to both published player variants."""
from pathlib import Path
def apply_controls(s):
 if 'LOADING equ $fe70' in s:return s
 s=s.replace('D_ACTUAL equ $fe6f','D_ACTUAL equ $fe6f\nLOADING equ $fe70')
 s=s.replace("menu_key:\n        call key_get\n        cp '1'", "menu_key:\n        call key_get\n        cp 'Q'\n        jp z,quit\n        cp '1'")
 s=s.replace('.choose:ld (PROFILE),a\n        call preload\n        jp c,error_screen', '''.choose:ld (PROFILE),a
        xor a
        ld (STOP),a
        ld a,1
        ld (LOADING),a
        call preload
        push af
        xor a
        ld (LOADING),a
        pop af
        jr nc,.loaded
        cp E_CANCEL
        jp nz,error_screen
        jp stopped
.loaded:''')
 a=s.index('stopped:\n');b=s.index('        call screen_clear',a)
 restore=s[a:b].replace('stopped:\n','restore_host:\n')+'        ret\n'
 s=s[:a]+'''stopped:
        call restore_host
        jp c,error_screen
        ld a,(STOP)
        cp 2
        jp z,quit_reboot
        cp 3
        jp nz,menu
'''+s[b:]
 a=s.index('error_screen:')
 s=s[:a]+'''quit:
        call restore_host
        jp c,error_screen
quit_reboot:
        ; This full-control player overwrites BASIC's workspace: cold ROM
        ; entry is safe; returning through the original USR stack is not.
        di
        xor a
        out ($f4),a
        out ($ff),a
        im 1
        ld sp,$ffff
        jp $0000
'''+restore+s[a:]
 # Capture loading requests during serial receive, but finish the transaction.
 s=s.replace('        call poll_pump\n        pop hl', '        call poll_pump\n        ld a,(LOADING)\n        or a\n        call nz,keys\n        pop hl')
 s=s.replace('        call legacy_chdir\n        ret c\n.volume:', '        call legacy_chdir\n        ret c\n        call check_cancel\n        ret c\n.volume:')
 s=s.replace('        call legacy_mount\n        ret c\n        ld a,(LOAD_VOLUME)', '        call legacy_mount\n        ret c\n        call check_cancel\n        ret c\n        ld a,(LOAD_VOLUME)')
 s=s.replace(".sweep: ld a,'S'", ".sweep: call keys\n        call check_cancel\n        ret c\n        ld a,'S'")
 # Header and payload are separate completed wire transactions.
 a=s.index('read_code:');b=s.index('ensure_region:',a);part=s[a:b]
 part=part.replace('        call legacy_read_block\n        ret c','        call legacy_read_block\n        ret c\n        call check_cancel\n        ret c',1)
 part=part.replace('        jp legacy_read_block','        call legacy_read_block\n        ret c\n        jp check_cancel')
 s=s[:a]+part+'''check_cancel:
        ld a,(STOP)
        or a
        ret z
        ld a,E_CANCEL
        scf
        ret
'''+s[b:]
 a=s.index('keys:');b=s.index('prefetch:',a)
 s=s[:a]+'''keys:   ld a,(STOP)
        or a
        ret nz                       ; latch the first request until drained
        ld bc,$fbfe                 ; Q
        in a,(c)
        bit 0,a
        jr z,.quit
        ld bc,$7ffe                 ; Space
        in a,(c)
        bit 0,a
        jr z,.menu
        ld bc,$bffe                 ; Enter
        in a,(c)
        bit 0,a
        jr z,.menu
        ld bc,$fefe                 ; X retains the optional statistics screen
        in a,(c)
        bit 2,a
        ret nz
        ld a,3
        jr .request
.menu:  ld a,1
        jr .request
.quit:  ld a,2
.request:
        ld (STOP),a
        xor a
        ld (PLAY),a
        ret
'''+s[b:]
 s=s.replace("'X STOP  SPACE PAUSE / RESUME'", "'SPACE/ENTER MENU  Q QUIT'")
 s=s.replace("loading_text: db 'PRELOAD AND VERIFY 512K SRAM',13,'PLEASE WAIT - NO VIDEO YET',13,0", "loading_text: db 'PRELOAD AND VERIFY 512K SRAM',13,'SPACE/ENTER MENU  Q QUIT',13,'WAIT FOR CURRENT TRANSFER',13,'X STATS DURING PLAYBACK',13,0")
 return s

if __name__=='__main__':
 for name in ('sc512_player.asm','sw512_player.asm'):
  p=Path('src')/name;p.write_text(apply_controls(p.read_text()));print(p)
