"""Convert source video to sequential legacy TAP / TSVideoCodec ECM samples.

Only the Pico's existing TAP block LOAD protocol is used. PackBits and XOR
payloads use the existing TSVideoCodec encoder/reference decoder unchanged.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import shutil
import struct
import subprocess
import sys

import numpy as np
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]


def tap_block(flag, payload):
    check = flag
    for value in payload:
        check ^= value
    return struct.pack('<H', len(payload)+2)+bytes([flag])+payload+bytes([check])


def code_pair(name, data):
    assert 0 < len(data) <= 16384
    header = bytes([3])+name.encode().ljust(10, b' ')+struct.pack('<HHH', len(data), 0x9000, 0x8000)
    assert len(header) == 17
    return tap_block(0, header)+tap_block(255, data)


def write_stream(path, frames, fps, start, duration, codec):
    records, expected, stats = [], bytearray(), []
    previous = None
    for index, frame in enumerate(frames):
        bitmap = codec.encode_packbits(frame.bitmap)
        attrs = codec.encode_packbits(frame.attributes)
        packed = bitmap+attrs
        kind, data = 7, packed
        if previous is not None:
            if frame == previous:
                kind, data = 3, b''
            else:
                delta, _ = codec.encode_xor(previous, frame)
                if len(delta) < len(packed):
                    kind, data = 5, delta
        if kind == 5:
            assert codec.decode_xor(previous, data) == frame
        elif kind == 7:
            assert codec.decode_packbits(bitmap, 6144) == frame.bitmap
            assert codec.decode_packbits(attrs, 6144) == frame.attributes
        packet = b'LVF1'+struct.pack('<HBBH', index, kind, 0, len(data))+data
        assert len(packet) <= 16384
        records.append(code_pair(f'F{index:05}', packet))
        expected.extend(frame.bitmap+frame.attributes)
        stats.append(dict(index=index, kind=kind, packet_bytes=len(packet),
                          ecm_sha256=hashlib.sha256(frame.bitmap+frame.attributes).hexdigest()))
        previous = frame
    maximum = max(s['packet_bytes'] for s in stats)
    metadata = struct.pack('<4sBBBBHHHHII8s', b'LVS1', 1, 60, 60//fps, 0,
                           len(frames), maximum, 256, 192,
                           round(start*1000), round(duration*1000), b'\0'*8)
    assert len(metadata) == 32
    data = code_pair('LVSMETA', metadata)+b''.join(records)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    path.with_suffix('.ecm').write_bytes(expected)
    result = dict(frames=len(frames), requested_fps=fps, source_start_seconds=start,
                  source_duration_seconds=duration, tap_bytes=len(data),
                  largest_packet=maximum, tap_sha256=hashlib.sha256(data).hexdigest(),
                  records=stats)
    path.with_suffix('.json').write_text(json.dumps(result, indent=2)+'\n')
    return result


def load_codec(root):
    sys.path.insert(0, str(root/'src/encoder'))
    from svd_ecm import ECMFrame, screen_offset, encode_attribute_video
    from svd_stream import encode_xor, decode_xor
    from keyframe_codec import encode_packbits, decode_packbits
    return argparse.Namespace(**locals())


def diagnostic_frames(codec, count=64):
    frames = []
    rng = np.random.default_rng(2068)
    texture = rng.integers(0, 256, 6144, dtype=np.uint8)
    for frame in range(count):
        bits, attrs = bytearray(texture), bytearray(6144)
        for y in range(192):
            for x in range(32):
                off = codec.screen_offset(y, x)
                attrs[off] = 0x40 | ((x//4+frame//4)%7+1)
                if (x-frame%24) % 32 < 8 and 48 <= y < 144:
                    bits[off] = ((0xf0 if y & 4 else 0x0f) ^ frame) & 255
                    attrs[off] = 0x78 | (frame%7)
        frames.append(codec.ECMFrame(bytes(bits), bytes(attrs)))
    return frames


def extract(source, folder, *, start, duration, fps, low_detail):
    folder.mkdir(parents=True, exist_ok=True)
    for old in folder.glob('source_*.png'):
        old.unlink()                    # this builder's generated frame cache only
    # Deterministic fit/letterbox; preserve the entire source composition.
    filters = [f'fps={fps}', 'scale=256:192:force_original_aspect_ratio=decrease',
               'pad=256:192:(ow-iw)/2:(oh-ih)/2']
    if low_detail:
        filters += ['scale=128:96:flags=area', 'scale=256:192:flags=neighbor']
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-ss', str(start), '-i', str(source),
                    '-t', str(duration), '-an', '-vf', ','.join(filters),
                    '-frames:v', str(math.ceil(duration*fps)),
                    str(folder/'source_%05d.png')], check=True)
    return sorted(folder.glob('source_*.png'))


def convert(paths, codec, root, work):
    native = root/'src/native_encoder/build/svdenc.exe'
    if not native.is_file():
        raise SystemExit('Provide TSVideoCodec native encoder at '+str(native))
    work.mkdir(parents=True, exist_ok=True)
    result = []
    for index, path in enumerate(paths):
        image = Image.open(path).convert('RGB')
        (work/'input.rgb').write_bytes(np.asarray(image, dtype=np.uint8).tobytes())
        subprocess.run([str(native), 'sierra', str(work/'input.rgb'), str(work/'output.pix'),
                        str(work/'output.atr'), '--brightness', '-0.02', '--contrast', '1',
                        '--gamma', '1.3', '--saturation', '1'], check=True,
                       stdout=subprocess.DEVNULL)
        result.append(codec.ECMFrame((work/'output.pix').read_bytes(), (work/'output.atr').read_bytes()))
        if index % 20 == 0 or index+1 == len(paths):
            print(f'Encoded {index+1}/{len(paths)} ECM frames', flush=True)
    return result


def previews(frames, folder, fps):
    folder.mkdir(parents=True, exist_ok=True)
    chosen = sorted(set([0, 1, len(frames)//4, len(frames)//2, len(frames)*3//4, len(frames)-1]))
    contact = Image.new('RGB', (768, 424), '#202020')
    draw = ImageDraw.Draw(contact)
    for index, number in enumerate(chosen):
        frame = frames[number].render()
        contact.paste(frame, ((index%3)*256, (index//3)*212))
        draw.text(((index%3)*256+4, (index//3)*212+194), f'frame {number} / {number/fps:.1f}s', fill='white')
    contact.save(folder/'contact.png')
    images = [frame.render() for frame in frames[:min(20, len(frames))]]
    images[0].save(folder/'preview.gif', save_all=True, append_images=images[1:],
                   duration=round(1000/fps), loop=0, optimize=False)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path)
    p.add_argument('--codec-root', type=Path, default=Path('D:/T7_Recover/Jon/Personal/Timex/TSVideoCodec'))
    p.add_argument('--start', type=float, default=36)
    p.add_argument('--out', type=Path, default=ROOT/'build/video-samples')
    p.add_argument('--max-seconds', type=float, default=0, help='0: all remaining source for TRAINALL')
    p.add_argument('--diagnostic-only', action='store_true')
    p.add_argument('--repack-only', action='store_true', help='repack verified existing ECM frames without reconverting source')
    args = p.parse_args()
    codec = load_codec(args.codec_root)
    args.out.mkdir(parents=True, exist_ok=True)
    cached = json.loads((args.out/'manifest.json').read_text()) if args.repack_only else None
    def cached_frames(name):
        info = cached['samples'][name]
        data = (args.out/name).with_suffix('.ecm').read_bytes()
        assert len(data) == info['frames']*12288
        result = []
        for i, stat in enumerate(info['records']):
            frame = data[i*12288:(i+1)*12288]
            assert hashlib.sha256(frame).hexdigest() == stat['ecm_sha256']
            result.append(codec.ECMFrame(frame[:6144], frame[6144:]))
        return result
    report = dict(codec='TSVideoCodec PackBits keyframes + raw-offset XOR deltas',
                  audio=False, hardware_tested=False, samples={})
    pattern = diagnostic_frames(codec)
    report['samples']['PATTERN.TAP'] = write_stream(args.out/'PATTERN.TAP', pattern[:8], 2, 0, 4, codec)
    report['samples']['STRESS.TAP'] = write_stream(args.out/'STRESS.TAP', pattern, 2, 0, 32, codec)
    previews(pattern, args.out/'pattern-preview', 2)
    if not args.diagnostic_only:
        if not args.input or not args.input.is_file():
            p.error('--input must point to the source video')
        info = json.loads(subprocess.check_output(['ffprobe', '-v', 'error', '-show_entries',
                                                   'format=duration', '-of', 'json', str(args.input)]))
        remaining = float(info['format']['duration'])-args.start
        if args.start < 0 or remaining <= 0:
            p.error('start must be inside the video')
        duration = min(remaining, args.max_seconds) if args.max_seconds else remaining
        source_hash = hashlib.sha256()
        with args.input.open('rb') as src:
            for chunk in iter(lambda: src.read(1024*1024), b''):
                source_hash.update(chunk)
        report.update(source=str(args.input), source_sha256=source_hash.hexdigest(), start=args.start,
                      fit='256x192 aspect-preserving fit; 2fps profile uses TSVideoCodec 32x24 attribute video')
        if cached:
            assert cached['source_sha256'] == report['source_sha256'] and cached['start'] == args.start
            assert cached['samples']['TRAINALL.TAP']['source_duration_seconds'] == duration
            quality = cached_frames('TRAINALL.TAP')
        else:
            source_frames = extract(args.input, args.out/'quality-frames', start=args.start,
                                    duration=duration, fps=1, low_detail=False)
            quality = convert(source_frames, codec, args.codec_root, args.out/'native-work')
        first = quality[:60]
        report['samples']['TRAIN0.TAP'] = write_stream(args.out/'TRAIN0.TAP', quality[:4], 1, args.start, min(duration, 4), codec)
        report['samples']['TRAIN1.TAP'] = write_stream(args.out/'TRAIN1.TAP', first, 1, args.start, min(duration, 60), codec)
        report['samples']['TRAINALL.TAP'] = write_stream(args.out/'TRAINALL.TAP', quality, 1, args.start, duration, codec)
        previews(first, args.out/'train-preview', 1)
        short = min(duration, 60)
        if cached:
            quick = cached_frames('TRAIN2.TAP')
        else:
            source_frames = extract(args.input, args.out/'cadence-frames', start=args.start,
                                    duration=short, fps=2, low_detail=True)
            quick = [codec.encode_attribute_video(np.asarray(Image.open(path).convert('RGB')), 24)
                     for path in source_frames]
        report['samples']['TRAIN2.TAP'] = write_stream(args.out/'TRAIN2.TAP', quick, 2, args.start, short, codec)
        report['samples']['TRAIN2.TAP']['profile'] = 'TSVideoCodec 32x24 attribute video, expanded to ECM; fixed checker bitmap'
        previews(quick, args.out/'cadence-preview', 2)
        report['encoder_settings'] = dict(native_sha256=hashlib.sha256((args.codec_root/'src/native_encoder/build/svdenc.exe').read_bytes()).hexdigest(),
                                           brightness=-.02, contrast=1, gamma=1.3, saturation=1)
    (args.out/'manifest.json').write_text(json.dumps(report, indent=2)+'\n')
    print('Samples complete: '+str(args.out), flush=True)


if __name__ == '__main__':
    main()
