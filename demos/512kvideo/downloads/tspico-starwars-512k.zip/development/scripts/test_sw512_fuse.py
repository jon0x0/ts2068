"""Cold-load the ordinary RAM TAP in Fuse's TS2068 model."""
from pathlib import Path
import subprocess,json,hashlib,re
from build import symbols
ROOT=Path(__file__).resolve().parents[1]
s=symbols(ROOT/'build/sw512.sym')
commands=f'''breakpoint 0x{s['menu_key']:x} if z80:sp == 0xfff0 && [0xe100] == 0xf3
commands 1
print z80:pc
print z80:sp
print [0xf8ff]+256*[0xf900]
print [0xf9f9]
print z80:im
out 255 2
set z80:iff1 1
set z80:iff2 1
delete 1
continue
end
breakpoint 0x{s['irq']+12:x} if [{s['TICK']}] == 1
commands 2
print z80:pc
print [{s['TICK']}]
exit 0
end'''
si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=subprocess.SW_HIDE
r=subprocess.run(['C:/Program Files (x86)/Fuse/fuse.exe','--machine','ts2068','--no-sound',
    '--no-loading-sound','--no-autosave-settings','--speed','5000',
    '--tape',str(ROOT/'build/SW512.TAP'),'--auto-load','--debugger-command',commands],
    capture_output=True,text=True,timeout=45,startupinfo=si)
print(r.returncode,r.stdout+r.stderr)
values=[int(v,16) for v in re.findall(r'^0x([0-9a-f]+)\s*$',r.stdout,re.M)]
assert r.returncode==0 and values==[s['menu_key'],0xfff0,0xf9f9,0xc3,2,s['irq']+12,1],values
(ROOT/'build/sw512-fuse-validation.json').write_text(json.dumps(dict(passed=True,
    tape_sha256=hashlib.sha256((ROOT/'build/SW512.TAP').read_bytes()).hexdigest(),
    player_sha256=hashlib.sha256((ROOT/'build/sw512.bin').read_bytes()).hexdigest(),
    machine='TS2068',auto_tape_load=True,im2_vector=0xf9f9,
    im2_interrupt_executed=True),indent=2)+'\n')
