"""Pack the user's exact 44.5--52.0 second clip using RAM512 paired patches."""
from pathlib import Path
import subprocess,sys,struct,json,hashlib
import numpy as np
sys.path[:0]=['scripts','references/TSVideoCodec-ram512']
from svd_ecm import ECMFrame,screen_offset
from trench_quantizer import quantize,preview
from build_video_samples import code_pair
from PIL import Image,ImageDraw
O=Path('build/trench');O.mkdir(exist_ok=True)
SRC='C:/video/STAR WARS EPISODE IV DESPECIALIZED Lukes Trench Run (Remastered to 4K48fps).mp4'
PAD=struct.pack('<HH',0x5800,0)*64
hsh=lambda b:hashlib.sha256(b).hexdigest()
def physical(raw,w,h):
 n=w*h//8;out=[bytearray(6144),bytearray(6144)];x=(256-w)//16;y0=(192-h)//2
 for y in range(h):
  off=screen_offset(y+y0,x)
  for p in range(2):out[p][off:off+w//8]=raw[p*n+y*w//8:p*n+(y+1)*w//8]
 return ECMFrame(bytes(out[0]),bytes(out[1]))
def words(old,new):
 out=bytearray()
 for off in range(0,6144,2):
  for a,b,base in ((old.bitmap,new.bitmap,0x4000),(old.attributes,new.attributes,0x6000)):
   if a[off:off+2]!=b[off:off+2]:out+=struct.pack('<H',base+off)+b[off:off+2]
 if not out:out+=PAD
 while len(out)%256:out+=struct.pack('<HH',0x5800,0)
 return bytes(out)
def pack(fs,packets):
 pages=[bytearray(b'RAMV'+bytes([p,1 if p<2 else 2])+bytes(250)+PAD*31) for p in range(64)]
 pages[0][256:6400]=fs[0].bitmap;pages[1][256:6400]=fs[0].attributes
 page=2;block=0;index=bytearray();meaningful=12288
 for data in packets:
  n=len(data)//256
  if n>93:raise OverflowError('frame exceeds three cache pages')
  if n+block>93 and block:page+=1;block=0
  endpage=page+(block+n-1)//31
  if endpage>=64:raise OverflowError('512 KiB full')
  index+=bytes([page,block])+struct.pack('<H',n)
  for i in range(n):
   pages[page][256+block*256:512+block*256]=data[i*256:(i+1)*256]
   block+=1
   if block==31:page+=1;block=0
  meaningful+=len(data)
 return pages,bytes(index),endpage,meaningful
def prepare(w,h,fps):
 d=O/f'{w}x{h}-{fps}';d.mkdir(exist_ok=True);cache=d/'quantized.bin'
 if cache.exists():
  raw=cache.read_bytes();return [ECMFrame(raw[i:i+6144],raw[i+6144:i+12288]) for i in range(0,len(raw),12288)]
 data=subprocess.check_output(['ffmpeg','-v','error','-ss','44.5','-i',SRC,'-t','7.5','-an','-vf',f'fps={fps},scale={w}:{h}:flags=lanczos','-pix_fmt','rgb24','-f','rawvideo','pipe:1'])
 size=w*h*3;assert len(data)%size==0
 fs=[];old=None
 for i in range(len(data)//size):
  rgb=np.frombuffer(data[i*size:(i+1)*size],dtype=np.uint8).reshape(h,w,3)
  old=quantize(rgb,old);fs.append(physical(old,w,h))
  if i%24==0:print(w,h,fps,'frame',i,flush=True)
 cache.write_bytes(b''.join(f.bitmap+f.attributes for f in fs));return fs
def build(tag,w,ht,fps):
 fs=prepare(w,ht,fps);n=len(fs)
 packets=[words(a,b) for a,b in zip(fs,fs[1:])]+[words(fs[-1],fs[0])]
 print('candidate',w,ht,fps,'frames',n,'patch bytes',sum(map(len,packets)),'maximum',max(map(len,packets)),flush=True)
 pages,index,last,meaningful=pack(fs,packets)
 # Independently apply every record, including the last-to-first transition.
 state=[bytearray(fs[0].bitmap),bytearray(fs[0].attributes)]
 for i,packet in enumerate(packets):
  for address,value in struct.iter_unpack('<HH',packet):
   if address==0x5800:continue
   assert address%2==0 and (0x4000<=address<=0x57fe or 0x6000<=address<=0x77fe)
   plane=0 if address<0x6000 else 1;base=0x4000 if plane==0 else 0x6000
   state[plane][address-base:address-base+2]=value.to_bytes(2,'little')
  assert state[0]==fs[(i+1)%n].bitmap and state[1]==fs[(i+1)%n].attributes
 d=O/tag;d.mkdir(exist_ok=True);image=b''.join(pages);raw=b''.join(f.bitmap+f.attributes for f in fs)
 sums=b''.join(struct.pack('<H',sum(p)&65535) for p in pages)
 meta=bytearray(64);meta[:4]=b'R512';meta[4:8]=bytes([1,60//fps,64,last]);struct.pack_into('<HHHHHI',meta,8,n,n,len(index),w,ht,meaningful)
 for name,data in [('sram.bin',image),('frames.ecm',raw),('meta.bin',meta),('index.bin',index),('sums.bin',sums)]: (d/name).write_bytes(data)
 vols=[]
 for vi in range(16):
  data=(code_pair('RAM META',meta)+code_pair('RAM INDEX',index)+code_pair('RAM SUMS',sums)) if vi==0 else b''
  data+=b''.join(code_pair(f'RAM {p:02}',pages[p]) for p in range(vi*4,vi*4+4))
  name=f'SW{tag}{vi:03}.TAP';(O/name).write_bytes(data);vols.append(dict(name=name,bytes=len(data),sha256=hsh(data)))
 return dict(width=w,height=ht,fps_target=fps,ticks_per_frame=60//fps,source_start=44.5,source_end=52,source_frames=n,source_seconds=7.5,playback_seconds=n/fps,sram_bytes=524288,meaningful_bytes=meaningful,utilization=meaningful/524288,record_count=n,max_blocks=max(map(len,packets))//256,mean_frame_bytes=sum(map(len,packets))/n,volumes=vols,image_sha256=hsh(image),frames_sha256=hsh(raw),codec='paired 16-bit replacements; fixed 256-byte blocks',quality='natural 8x1; saturation 1.0 gamma 1.06 emitted chroma cost .18; fixed spatial Bayer',all_frames_exact=True)
if __name__=='__main__':
 profiles={};candidates=[]
 for tag,w,ht,fps in [('F',256,108,12),('W',256,108,15),('W',240,102,15),('W',224,94,15),('F',240,102,12),('F',224,94,12)]:
  if tag in profiles:continue
  try:p=build(tag,w,ht,fps);profiles[tag]=p;candidates.append(dict(tag=tag,width=w,height=ht,fps=fps,fits=True))
  except OverflowError as e:candidates.append(dict(tag=tag,width=w,height=ht,fps=fps,fits=False,reason=str(e)));print(str(e),flush=True)
 assert set(profiles)=={'F','W'},candidates
 (O/'manifest.json').write_text(json.dumps(dict(version=1,source=SRC,source_sha256=hsh(Path(SRC).read_bytes()),profiles=profiles,candidates=candidates),indent=2)+'\n')
 print(json.dumps({tag:{k:p[k] for k in ('width','height','source_frames','fps_target','meaningful_bytes')} for tag,p in profiles.items()},indent=2))
