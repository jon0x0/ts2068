"""Deterministic sjasmplus build. Run under Linux/WSL, or set SJASMPLUS."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / 'build'

# Original compact uppercase 5x7 font. Lowercase shares uppercase glyphs.
GLYPHS = {
'A':'0e11111f111111','B':'1e11111e11111e','C':'0f10101010100f',
'D':'1e11111111111e','E':'1f10101e10101f','F':'1f10101e101010',
'G':'0f10101711110f','H':'1111111f111111','I':'0e04040404040e',
'J':'0702020212120c','K':'11121418141211','L':'1010101010101f',
'M':'111b1515111111','N':'11191513111111','O':'0e11111111110e',
'P':'1e11111e101010','Q':'0e11111115120d','R':'1e11111e141211',
'S':'0f10100e01011e','T':'1f040404040404','U':'1111111111110e',
'V':'11111111110a04','W':'11111115151b11','X':'11110a040a1111',
'Y':'11110a04040404','Z':'1f01020408101f',
'0':'0e11131519110e','1':'040c040404040e','2':'0e11010204081f',
'3':'1e01010601011e','4':'02060a121f0202','5':'1f10101e01011e',
'6':'0e10101e11110e','7':'1f010204080808','8':'0e11110e11110e',
'9':'0e11110f01010e',' ':'00000000000000','.':'00000000000c0c',
',':'00000000000c08',':':'000c0c000c0c00',';':'000c0c000c0800',
'/':'01010204081010','\\':'10100804020101','-':'0000001f000000',
'_':'0000000000001f','=':'00001f001f0000','>':'10080402040810',
'<':'01020408040201','?':'0e110102040004','!':'04040404040004',
'(':'02040808080402',')':'08040202020408','[':'0e08080808080e',
']':'0e02020202020e','+':'0004041f040400','*':'00150e1f0e1500',
'"':'0a0a0000000000',"'":'04040000000000','$':'040f140e051e04',
'#':'0a1f0a0a1f0a00','%':'19190204081313','@':'0e11171d10100f',
}


def assemble(name, source, **defines):
    assembler = os.environ.get('SJASMPLUS') or shutil.which('sjasmplus')
    if not assembler:
        assembler = str(ROOT / 'tools/sjasmplus-source/sjasmplus')
    args = [assembler, '--nologo', '--msg=war', f'--raw={BUILD/name}.bin',
            f'--sym={BUILD/name}.sym', f'--lst={BUILD/name}.lst']
    args += [f'-D{k}={v}' for k, v in defines.items()]
    subprocess.run(args + [source], cwd=ROOT / 'src', check=True)


def symbols(path):
    result = {}
    for line in path.read_text().splitlines():
        k, sep, v = line.partition(': EQU ')
        if sep:
            result[k] = int(v, 16)
    return result


def main():
    BUILD.mkdir(exist_ok=True)
    font = bytearray()
    for n in range(32, 128):
        rows = bytes.fromhex(GLYPHS.get(chr(n).upper(), GLYPHS['?']))
        font.extend(bytes([0]) + bytes(b << 2 for b in rows))
    (BUILD/'font.bin').write_bytes(font)
    manifest = {'firmware_required': 'profile dependent: modern 2.3 or legacy single FIFO TAP',
                'hardware_tested': False, 'profiles': {}}
    for name, source, enabled in (
            ('filebrowse', 'demo.asm', 0),
            ('filebrowse-stream', 'demo.asm', 1),
            ('filebrowse-legacy', 'demo_legacy.asm', 0),
            ('video-legacy', 'video_legacy.asm', 0),
            ('video2-legacy', 'video2_legacy.asm', 0),
            ('video10-128-legacy', 'video10_128.asm', 0),
            ('video10-96-legacy', 'video10_96.asm', 0),
            ('video160-legacy', 'video160_legacy.asm', 0)):
        assemble(name, source, ENABLE_STREAM=enabled)
        rom = (BUILD/f'{name}.bin').read_bytes()
        assert len(rom) == 16384 and rom[:2] == bytes.fromhex('00 ff')
        # Standard machine-code AROS fallback. OS maps only chunk 4; this
        # bootstrap enables low ROM while its own instructions stay visible.
        boot = bytes.fromhex('02 02 08 80 ef 01 00 00 f3 31 f0 ff 3e 13 d3 f4 c3 00 01')
        boot = boot.ljust(8192, b'\xff')
        chunks = {0: rom[:8192], 1: rom[8192:], 4: boot}
        dck = bytes([0, 2, 2, 0, 0, 2, 0, 0, 0]) + b''.join(chunks.values())
        flat = b''.join(chunks.get(i, b'\xff'*8192) for i in range(8))
        (BUILD/f'{name}.dck').write_bytes(dck)
        (BUILD/f'{name}-64k.bin').write_bytes(flat)
        syms = symbols(BUILD/f'{name}.sym')
        manifest['profiles'][name] = {
            'rom_used': syms['program_end'], 'dck_bytes': len(dck),
            'dck_sha256': hashlib.sha256(dck).hexdigest(),
            'physical_sha256': hashlib.sha256(flat).hexdigest(),
            'stream_module': bool(enabled),
            'protocol': 'legacy single FIFO / TAP' if name.endswith('legacy') else 'modern dual port / channels',
        }
    assemble('video160-ram', 'video160_ram.asm')
    for enabled in (0, 1):
        assemble('filelib-stream' if enabled else 'filelib', 'library.asm', ENABLE_STREAM=enabled)
    assemble('filedialogs', 'dialog_library.asm')
    assemble('filelib-legacy', 'library_legacy.asm')
    manifest['libraries'] = {name: (BUILD/f'{name}.bin').stat().st_size
                             for name in ('filelib','filelib-stream','filedialogs','filelib-legacy')}
    seed = BUILD/'sdcard/TAP/DEMO'
    seed.mkdir(parents=True, exist_ok=True)
    (seed/'HELLO.TXT').write_bytes(b'Hello from the SD card.\r\nCartridge code reads this without ROM calls.\r\n')
    (seed/'BYTES.BIN').write_bytes(bytes(range(256))*4)
    (seed/'STREAM.BIN').write_bytes(bytes(range(256))*128)
    for name in ('filebrowse','filebrowse-stream','filebrowse-legacy'):
        shutil.copyfile(BUILD/f'{name}.dck', BUILD/f'sdcard/TAP/{name}.dck')
    (BUILD/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
    print(json.dumps(manifest, indent=2))


if __name__ == '__main__':
    main()
