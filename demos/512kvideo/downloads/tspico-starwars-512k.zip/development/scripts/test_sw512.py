import sys,json,time,hashlib,argparse
from pathlib import Path
sys.path[:0]=['scripts','tests']
from ram512_machine import ROOT
from test_ram512c_bus import BusLatch as RamMachine
parser=argparse.ArgumentParser();parser.add_argument('profile',choices=['F','W']);parser.add_argument('delay',type=float,nargs='?',default=.05);parser.add_argument('--cached',action='store_true');parser.add_argument('--seed',action='store_true');parser.add_argument('--no-copy-shortcut',action='store_true');parser.add_argument('--loops',type=int,default=2);args=parser.parse_args()
O=ROOT/'build/trench';tag=args.profile;manifest=json.loads((O/'manifest.json').read_text());p=manifest['profiles'][tag]
files={v['name']:(O/v['name']).read_bytes() for v in p['volumes']}
m=RamMachine(name="sw512",files=files,bank_delay_s=args.delay,copy_shortcut=not args.no_copy_shortcut)
try:
 m.initialize();m.mem[m.syms['PROFILE']]=ord(tag)
 checkpoint=O/(tag+'-preloaded.bin');statefile=O/(tag+'-preloaded.json')
 cached=False
 if ('--cached' in sys.argv or '--seed' in sys.argv) and checkpoint.exists() and statefile.exists():
  state=json.loads(statefile.read_text())
  if (state['image_sha256']==hashlib.sha256(m.image).hexdigest() or '--seed' in sys.argv) and state['sram_sha256']==p['image_sha256']:
   m.mem[:]=checkpoint.read_bytes();m.mem[0xe000:0xc000+len(m.image)]=m.image[0x2000:];m.sram[:]=(O/tag/'sram.bin').read_bytes();m.pico.region=state['region'];m.actual_mem=1;m.actual_region=state['region'];cached=True
 if not cached:
  c=m.call('preload',max_steps=150000000)
  assert not c.cf,('preload error',hex(c.a),m.mem[m.syms['LOAD_PAGE']],hex(c.pc))
  assert m.sram==(O/tag/'sram.bin').read_bytes(),'512 KiB SRAM differs'
  checkpoint.write_bytes(m.mem);statefile.write_text(json.dumps(dict(image_sha256=hashlib.sha256(m.image).hexdigest(),sram_sha256=p['image_sha256'],region=m.pico.region,passed=True,all_64_pages_readback=True),indent=2)+'\n')
  print('all 512 KiB loaded and verified',flush=True)
 command_start=len(m.pico.traces)
 m.next_irq=m.cpu.t+59736
 c=m.call('begin_play',max_steps=10000000);assert not c.cf,('begin error',hex(c.a))
 start=m.cpu.t;m.frames.clear();m.frame_ticks.clear();m.frame_ts.clear();m.cpu.pc=m.syms['menu_key.play'];m.cpu.sp=0xfff0
 target=args.loops*p['source_frames'];last=-1
 for step in range(8000000):
  if m.word('SHOWN')>=target and not m.mem[m.syms['BUSY']]:break
  if m.cpu.pc==m.syms['error_screen']:raise AssertionError(('player error',hex(m.cpu.a),m.mem[m.syms['FETCH_PAGE']],m.events[-20:],m.mem[m.syms['LEGACY_PHASE']],m.mem[m.syms['REPLY_STATUS']]))
  if len(m.frames)!=last and len(m.frames)%20==0:
   last=len(m.frames);print('shown',last,'ticks',m.word('TICK'),'late',m.word('LATE'),'wall',round(time.time()-m.wall_start,1),flush=True)
  m.cpu.step()
 else:raise AssertionError(('stalled',len(m.frames),hex(m.cpu.pc)))
 raw=(O/tag/'frames.ecm').read_bytes();expected=[raw[i:i+12288] for i in range(0,len(raw),12288)]
 for i,f in enumerate(m.frames):assert f==expected[(i+1)%len(expected)],('wrong frame',i)
 assert m.word('LOOPS')==args.loops
 assert not m.pico.errors,m.pico.errors
 assert m.hsr==0
 ticks=m.word('TICK');fps=target*60/ticks
 result=dict(passed=True,hardware_tested=False,profile=tag,frames=target,loops=m.word('LOOPS'),ticks=ticks,effective_fps=fps,late_starts=m.word('LATE'),bank_delay_s=m.bank_delay_s,all_frames_exact=True,sram_bytes=524288,loaded_through_legacy_protocol=not cached,copy_shortcut=m.copy_shortcut,image_sha256=hashlib.sha256(m.image).hexdigest(),sram_sha256=p['image_sha256'],samples_sha256=hashlib.sha256((O/'manifest.json').read_bytes()).hexdigest(),frame_start_or_finish_ticks=m.frame_ticks)
 end_tick=ticks
 m.mem[m.syms['PLAY']]=0
 for _ in range(10000000):
  if m.cpu.pc==m.syms['menu_key.play'] and not m.mem[m.syms['BANK_CMD']]:break
  m.cpu.step()
 else:raise AssertionError('command did not drain')
 assert m.sram==(O/tag/'sram.bin').read_bytes(),'playback modified SRAM'
 assert all(body[3:-1].lower()==b'tpi:memdock' for pre,body in m.pico.traces[command_start:]),'SD command during playback'
 result.update(bank_commands=m.word('B_COUNT'),bank_total_ticks=m.word('B_TOTAL'),bank_max_ticks=m.word('B_MAX'),no_sd_file_reads_during_playback=True)
 suffix=('-latency'+str(round(args.delay*1000))) if args.delay!=.05 else ''
 suffix+= '-strict' if args.no_copy_shortcut else ''
 (O/(tag+suffix+'-validation.json')).write_text(json.dumps(result,indent=2)+'\n');print(result,flush=True)
finally:m.pico.close()
