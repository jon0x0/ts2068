"""Real key-matrix tests: safe menu/quit during playback and serial loading."""
import sys,json,hashlib
from pathlib import Path
sys.path[:0]=['tests','scripts']
from ram512_machine import ROOT
from test_ram512c_bus import BusLatch
from test_cartridge import matrix_key
def verify(name,folder):
 O=ROOT/'build'/folder;manifest=json.loads((O/'manifest.json').read_text());results=[]
 files={v['name']:(O/v['name']).read_bytes() for p in manifest['profiles'].values() for v in p['volumes']}
 def machine(loaded=False):
  m=BusLatch(name=name,files=files,bank_delay_s=.05);m.initialize()
  if loaded:
   state=json.loads((O/'W-preloaded.json').read_text());m.mem[:]=(O/'W-preloaded.bin').read_bytes()
   m.mem[0xe000:0xc000+len(m.image)]=m.image[0x2000:]
   m.sram[:]=(O/'W/sram.bin').read_bytes();m.pico.region=state['region'];m.actual_mem=1;m.actual_region=state['region']
   m.mem[m.syms['LOADING']]=0;m.mem[m.syms['STOP']]=0;m.next_irq=m.cpu.t+59736
   c=m.call('begin_play',max_steps=10000000);assert not c.cf
   m.cpu.pc=m.syms['menu_key.play'];m.cpu.sp=0xfff0
  return m
 def run(m,done,limit=4000000,inject=None):
  for _ in range(limit):
   if done():return
   if m.cpu.pc==m.syms['error_screen']:raise AssertionError(('error',m.cpu.a,chr(m.mem[m.syms['D_STAGE']])))
   if inject:inject()
   m.cpu.step()
  raise AssertionError(('stalled',hex(m.cpu.pc),m.mem[m.syms['STOP']]))
 def safe(m,quit=False):
  assert m.hsr==0 and m.pico.memtype==2 and m.pico.region==0
  assert not m.cpu.iff and not m.mem[m.syms['PLAY']] and not m.mem[m.syms['BANK_CMD']] and not m.mem[m.syms['LOADING']]
  assert m.decr==(0 if quit else 0x40)
  if quit:assert m.cpu.pc==0 and m.cpu.sp==0xffff
  m.pico.clean()
 for key in (' ','\r','Q','X'):
  m=machine(True)
  try:
   m.held=matrix_key(key)
   done=(lambda:m.cpu.pc==0) if key=='Q' else ((lambda:m.cpu.pc==m.syms['key_get'] and m.mem[m.syms['STOP']]==3 and m.pico.memtype==2) if key=='X' else (lambda:m.cpu.pc==m.syms['menu_key']))
   run(m,done);safe(m,key=='Q')
   if key in (' ','\r'):
    # A subsequent choice starts a fresh load, not the latched cancellation.
    m.held=set();m.cpu.a=ord('F');m.cpu.pc=m.syms['menu_key.choose']
    run(m,lambda:m.cpu.pc==m.syms['preload'])
    assert m.mem[m.syms['STOP']]==0 and m.mem[m.syms['LOADING']]==1
   results.append('playback '+repr(key))
  finally:m.pico.close()
 # Stop while a region command is actually in flight; its reply must drain.
 for key in (' ','Q'):
  m=machine(True)
  try:
   run(m,lambda:bool(m.mem[m.syms['BANK_CMD']]) and m.cpu.pc==m.syms['tpi_rx'])
   m.held=matrix_key(key);run(m,(lambda:m.cpu.pc==0) if key=='Q' else (lambda:m.cpu.pc==m.syms['menu_key']))
   safe(m,key=='Q');results.append('bank response '+repr(key))
  finally:m.pico.close()
 # A short press during data reception is latched, but checksum/ack/reply finish.
 for key in (' ','\r','Q'):
  m=machine()
  try:
   m.cpu.a=ord('F');m.cpu.pc=m.syms['menu_key.choose'];m.cpu.sp=0xfff0;pressed=[False]
   def inject():
    if not pressed[0] and m.cpu.pc==m.syms['full_rx_payload']:
     pressed[0]=True;m.held=matrix_key(key)
    if m.mem[m.syms['STOP']]:m.held=set()
   run(m,(lambda:m.cpu.pc==0) if key=='Q' else (lambda:pressed[0] and m.cpu.pc==m.syms['menu_key']),inject=inject)
   assert pressed[0];safe(m,key=='Q')
   if key!='Q':
    m.mem[m.syms['STOP']]=0
    c=m.call('legacy_mount',hl=m.syms['FILE_NAME']);assert not c.cf
    c=m.call('read_code',de=m.syms['META'],bc=64);assert not c.cf
    assert m.mem[m.syms['META']:m.syms['META']+4]==b'R512'
    m.pico.clean()
   results.append('loading '+repr(key))
  finally:m.pico.close()
 m=machine()
 try:
  run(m,lambda:m.cpu.pc==m.syms['key_get.press']);m.held=matrix_key('Q')
  run(m,lambda:m.cpu.pc==0);safe(m,True);results.append('menu Q')
 finally:m.pico.close()
 r=dict(passed=True,cases=results,space_enter_return_directly_to_menu=True,quit_restores_flash_and_enters_rom_zero=True,loading_cancellation_drains_transaction=True,subsequent_file_load_after_cancel=True,x_statistics_retained=True,image_sha256=hashlib.sha256((ROOT/'build'/f'{name}.bin').read_bytes()).hexdigest())
 (O/'controls-validation.json').write_text(json.dumps(r,indent=2)+'\n');print(r)
if __name__=='__main__':verify(sys.argv[1],sys.argv[2])
