from pathlib import Path
import subprocess,json
import numpy as np
from PIL import Image,ImageDraw
from full160_v7_quantizer import quantize as baseline,preview
from trench_quantizer import quantize
O=Path('build/trench');O.mkdir(exist_ok=True)
SRC='C:/video/STAR WARS EPISODE IV DESPECIALIZED Lukes Trench Run (Remastered to 4K48fps).mp4'
times=[44.5,45.5,47,49,50.5,51.5]
canvas=Image.new('RGB',(512*4,256*len(times)),(24,24,24));draw=ImageDraw.Draw(canvas)
for row,t in enumerate(times):
 rgb=subprocess.check_output(['ffmpeg','-v','error','-ss',str(t),'-i',SRC,'-frames:v','1','-vf','scale=256:108:flags=lanczos','-pix_fmt','rgb24','-f','rawvideo','pipe:1'])
 a=np.frombuffer(rgb,dtype=np.uint8).reshape(108,256,3)
 variants=[('Source',Image.fromarray(a).resize((512,216))),('V7 previous',preview(baseline(a),256,108,2)),('Natural chroma .18',preview(quantize(a),256,108,2)),('Natural chroma .35',preview(quantize(a,chroma_cost=.35),256,108,2))]
 for col,(title,im) in enumerate(variants):
  x=col*512;y=row*256;canvas.paste(im,(x,y+30));draw.text((x+8,y+8),f'{t}s {title}',fill='white')
canvas.save(O/'colour-comparison.png')
print(O/'colour-comparison.png')
