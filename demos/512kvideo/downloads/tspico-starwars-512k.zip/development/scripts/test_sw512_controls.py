import sys,json,hashlib
sys.path[:0]=['tests','scripts']
from ram512_machine import ROOT
from test_ram512c_bus import BusLatch as RamMachine
from test_cartridge import matrix_key
O=ROOT/'build/trench';m=RamMachine(name="sw512",bank_delay_s=.05)
try:
 m.initialize();state=json.loads((O/'W-preloaded.json').read_text());assert state['image_sha256']==hashlib.sha256(m.image).hexdigest()
 m.mem[:]=(O/'W-preloaded.bin').read_bytes();m.sram[:]=(O/'W/sram.bin').read_bytes();m.pico.region=state['region'];m.actual_mem=1;m.actual_region=state['region'];m.next_irq=m.cpu.t+59736
 c=m.call('begin_play',max_steps=10000000);assert not c.cf
 m.cpu.pc=m.syms['menu_key.play'];m.cpu.sp=0xfff0
 m.held=matrix_key(' ')
 for _ in range(10000):
  if m.mem[m.syms['PAUSED']]:break
  m.cpu.step()
 else:raise AssertionError('space did not pause')
 before=bytes(m.mem[0x4000:0x5800])+bytes(m.mem[0x6000:0x7800]);shown=m.word('SHOWN');m.held=set()
 for _ in range(50000):m.cpu.step()
 assert m.word('SHOWN')==shown and bytes(m.mem[0x4000:0x5800])+bytes(m.mem[0x6000:0x7800])==before
 m.held=matrix_key(' ')
 for _ in range(10000):
  if not m.mem[m.syms['PAUSED']]:break
  m.cpu.step()
 else:raise AssertionError('space did not resume')
 m.held=set()
 for _ in range(500000):
  if m.word('SHOWN')>shown and not m.mem[m.syms['BUSY']]:break
  m.cpu.step()
 else:raise AssertionError('no frame after resume')
 m.held=matrix_key('X')
 for _ in range(3000000):
  if m.cpu.pc==m.syms['key_get'] and not m.mem[m.syms['PLAY']]:break
  m.cpu.step()
 else:raise AssertionError('X did not reach stopped stats')
 assert m.hsr==0 and m.pico.memtype==2 and m.pico.region==0
 assert not m.cpu.iff
 r=dict(passed=True,pause_preserves_frame=True,resume_plays=True,stop_restores_home_and_flash_dock0=True,image_sha256=hashlib.sha256(m.image).hexdigest())
 (O/'controls-validation.json').write_text(json.dumps(r,indent=2)+'\n');print(r)
finally:m.pico.close()
