from test_video_menu_controls import verify
verify('sw512','trench')
