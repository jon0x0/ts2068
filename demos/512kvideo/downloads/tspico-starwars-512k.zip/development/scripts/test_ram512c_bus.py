"""Regression: selector word queued after PIO is waiting for an access.

Bounded abstraction of pull -> wait(strobe) -> access -> wrap -> pull.
Not a claim of cycle-accurate electrical simulation or hardware confirmation.
"""
import sys,json,hashlib
sys.path[:0]=['tests','scripts']
from ram512_machine import RamMachine,ROOT
class BusLatch(RamMachine):
 def __init__(self,**kw):
  super().__init__(**kw);self.actual_mem=2;self.actual_region=0;self.pending=None
 def select(self,mem,slot):
  super().select(mem,slot);self.pending=(mem,slot//2)
 def advance(self):
  if self.pending:self.actual_mem,self.actual_region=self.pending;self.pending=None
 def read(self,a):
  if self.hsr&(1<<(a//8192)):
   v=self.sram[self.actual_region*65536+a] if self.actual_mem==1 else 255
   self.advance();return v
  return self.mem[a]
 def write(self,a,v):
  if self.hsr&(1<<(a//8192)):
   assert not self.mem[self.syms['PLAY']],'SRAM write during playback'
   if self.actual_mem==1:self.sram[self.actual_region*65536+a]=v
   self.advance();return
  return super().write(a,v)
if __name__=='__main__':
 O=ROOT/'build/ram512';files={'RVF000.TAP':(O/'RVF000.TAP').read_bytes()};results={}
 for name in ('ram512b','ram512c'):
  m=BusLatch(name=name,files=files)
  try:
   m.initialize();m.mem[m.syms['PROFILE']]=ord('F');m.cpu.sp=0xff00;m.cpu.push(0xfffe);m.cpu.pc=m.syms['preload']
   for _ in range(4000000):
    if m.cpu.pc==0xfffe:break
    if m.mem[m.syms['LOAD_PAGE']]==1 and m.cpu.pc==m.syms['preload.page']:break
    m.cpu.step()
   else:raise AssertionError('stalled')
   ok=m.mem[m.syms['LOAD_PAGE']]==1
   assert ok==(name=='ram512c')
   if ok:assert m.sram[:8192]==(O/'F/sram.bin').read_bytes()[:8192]
   results[name]=dict(first_page_verified=ok,error=None if ok else m.cpu.a,phase=m.mem[m.syms['LEGACY_PHASE']],stage=chr(m.mem[m.syms['D_STAGE']]),image_sha256=hashlib.sha256(m.image).hexdigest())
  finally:m.pico.close()
 out=dict(passed=True,hardware_cause_confirmed=False,results=results)
 (ROOT/'build/ram512c/bus-regression.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
