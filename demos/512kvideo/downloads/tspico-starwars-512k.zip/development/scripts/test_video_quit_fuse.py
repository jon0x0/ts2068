"""Native Fuse verifies the quit handoff reaches ROM 0000 with IM1 and DI."""
from pathlib import Path
import subprocess,json,hashlib,re,sys
from build import symbols
R=Path(__file__).resolve().parents[1];name=sys.argv[1];tap=sys.argv[2];s=symbols(R/f'build/{name}.sym')
commands=f'''set 0xfe71 0
breakpoint {s['menu_key']} if z80:sp == 0xfff0 && [0xe100] == 0xf3
commands 1
delete 1
set 0xfe71 165
set z80:sp 0x8123
set z80:im 2
out 255 2
set z80:pc {s['quit_reboot']}
continue
end
breakpoint 0 if [0xfe71] == 165
commands 2
print z80:pc
print z80:sp
print z80:im
print z80:iff1
print z80:iff2
exit 0
end'''
si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=subprocess.SW_HIDE
p=subprocess.run(['C:/Program Files (x86)/Fuse/fuse.exe','--machine','ts2068','--no-sound','--no-loading-sound','--no-autosave-settings','--speed','5000','--tape',str(R/'build'/tap),'--auto-load','--debugger-command',commands],capture_output=True,text=True,timeout=45,startupinfo=si)
values=[int(x,16) for x in re.findall(r'^0x([0-9a-f]+)\s*$',p.stdout,re.M)]
assert p.returncode==0 and values==[0,0xffff,1,0,0],(p.returncode,values,p.stdout,p.stderr)
r=dict(passed=True,real_fuse_z80=True,rom_entry=0,sp=65535,interrupt_mode=1,iff1=False,iff2=False,image_sha256=hashlib.sha256((R/f'build/{name}.bin').read_bytes()).hexdigest())
(R/f'build/{name}-fuse-quit-validation.json').write_text(json.dumps(r,indent=2)+'\n');print(r)
