"""Stock MEMDOCK mapping model; no Pico electrical timing is emulated."""
import inspect,textwrap,sys,json,time
from pathlib import Path
from test_cartridge import Machine,ROOT
from test_legacy import LegacyPico
import test_legacy
class BankPico(LegacyPico):
 def __init__(self,files,on_select):
  super().__init__(files=files);self.region=0;self.memtype=1;self.on_select=on_select;self.selections=[]
source=textwrap.dedent(inspect.getsource(LegacyPico.command))
source=source.replace("if cmd.upper() == 'TPI:DIR':",'''if cmd.upper() == 'TPI:MEMDOCK':
        mem=pre[3]+256*pre[4];slot=pre[5]+256*pre[6]
        assert mem in (1,2) and slot in range(0,16,2),(mem,slot)
        self.memtype=mem;self.region=slot//2;self.selections.append((mem,slot))
        self.on_select(mem,slot)
        self.message()
    elif cmd.upper() == 'TPI:DIR':''')
namespace=dict(vars(test_legacy));exec(source,namespace);BankPico.command=namespace['command']
class RamMachine(Machine):
 def __init__(self,files=None,bank_delay_s=0.0,copy_shortcut=True,name="ram512"):
  super().__init__(name);self.sram=bytearray(524288);self.pico=BankPico(files or {},self.select);self.pico.host_read_timeout=.1
  self.bank_delay_s=bank_delay_s;self.delay_until=0;self.next_irq=59736;self.irq_count=0;self.copy_shortcut=copy_shortcut
  self.event_points={self.syms[n] for n in ('select_region','legacy_execute','legacy_reply','ram_parameters')};self.events=[];self.frames=[];self.frame_ticks=[];self.frame_ts=[];self.mapping_events=[];self.load_volumes=[];self.wall_start=time.time()
  original=self.cpu._ed;cpu=self.cpu
  def ed():
   if cpu.read(cpu.pc)!=0xa0:return original()
   cpu.fetch();v=cpu.read(cpu.hl());cpu.write(cpu.get_rp(1),v)
   cpu.set_rp(2,cpu.hl()+1);cpu.set_rp(1,cpu.get_rp(1)+1);cpu.set_rp(0,cpu.get_rp(0)-1)
   cpu.f=(cpu.f&0xc1)|(4 if cpu.get_rp(0) else 0);cpu.t+=12
  cpu._ed=ed
 def select(self,mem,slot):
  if self.mem[self.syms['PLAY']]:self.delay_until=self.cpu.t+round(self.bank_delay_s*3528000)
 def read(self,a):
  if self.hsr&(1<<(a//8192)):
   assert not self.decr&128
   assert self.pico.memtype==1
   return self.sram[self.pico.region*65536+a]
  return self.mem[a]
 def write(self,a,v):
  if self.hsr&(1<<(a//8192)):
   assert self.pico.memtype==1
   assert not self.mem[self.syms['PLAY']],'SRAM write during playback'
   self.sram[self.pico.region*65536+a]=v;return
  assert a>=0x4000
  assert not 0xe000<=a<self.syms['program_end'],('HOME code overwritten',hex(a),hex(self.cpu.pc))
  self.mem[a]=v;self.writes.append(a)
 def port_in(self,port):
  if port&255 in (14,15) and self.cpu.t<self.delay_until:return 0
  if port&255 in (14,15) and hasattr(self,'pending_byte'):
   value=self.pending_byte;del self.pending_byte;return value
  value=super().port_in(port)
  if port&255 in (14,15) and self.cpu.t<self.delay_until:
   self.pending_byte=value;return 0
  return value
 def port_out(self,port,value):
  if port&255==0xf4:
   self.mapping_events.append((self.cpu.pc,value,self.pico.region))
   if value&128:assert not self.cpu.iff and 0x5b00<=self.cpu.pc<0x5b40
  super().port_out(port,value)
 def fetch(self,a):
  if a in self.event_points:self.events.append((hex(a),self.cpu.a,self.cpu.cf,self.word('TICK'),self.word('FRAME_PTR'),self.mem[self.syms['FETCH_PAGE']]))
  assert 0xe000<=a<self.syms['program_end'] or 0x5b00<=a<0x5b40,('bad fetch',hex(a),self.hsr)
  if self.cpu.iff and self.cpu.t>=self.next_irq:
   self.cpu.push(self.cpu.pc);self.cpu.pc=self.word(0xf9fa);self.cpu.iff=False
   self.next_irq=self.cpu.t+59736;self.irq_count+=1;return
  if self.name in ('ram512b','ram512c','sw512') and a==self.syms['video_settle.inner']:
   self.cpu.set_rp(0,0);self.cpu.a=0;self.cpu.f=0x44;self.cpu.t+=65536*26-5;self.cpu.pc+=5
   if self.pico.worker:self.pico.worker.join(timeout=.1)
   return
  if a==self.syms['preload.volume']:
   v=self.mem[self.syms['LOAD_VOLUME']];self.load_volumes.append(v)
   print('preload volume',v,'wall',round(time.time()-self.wall_start,1),flush=True)
  if a==self.syms['frame_done']:
   self.frames.append(bytes(self.mem[0x4000:0x5800])+bytes(self.mem[0x6000:0x7800]));self.frame_ticks.append(self.word('TICK'));self.frame_ts.append(self.cpu.t)
  if self.copy_shortcut and a==self.syms['copy256']:
   hl=self.cpu.hl();de=self.cpu.get_rp(1)
   for i in range(256):self.write((de+i)&65535,self.read((hl+i)&65535))
   self.cpu.set_rp(2,hl+256);self.cpu.set_rp(1,de+256);self.cpu.set_rp(0,0);self.cpu.f&=0xc1
   self.cpu.t+=5391 if self.name in ('ram512c','sw512') else 4116;self.cpu.pc=self.cpu.pop();return
 def initialize(self):
  self.cpu.pc=self.syms['start'];self.cpu.sp=0xfff0
  for _ in range(1000000):
   if self.cpu.pc==self.syms['menu_key']:return
   self.cpu.step()
  raise AssertionError('menu not reached')
 def run_frames(self,count,max_steps=100000000):
  # Equivalent main-loop trampoline. Returned calls retain the same RAM state;
  # pipeline timing gates are measured independently of Python wall time.
  for _ in range(max_steps):
   if len(self.frames)>=count:return
   if self.cpu.pc==0xfffe:
    self.cpu.sp=0xff00;self.cpu.push(0xfffe);self.cpu.pc=self.syms['pump' if self.next_call=='pump' else 'prefetch'];self.next_call='prefetch' if self.next_call=='pump' else 'pump'
   self.cpu.step()
  raise AssertionError(('playback stalled',len(self.frames),hex(self.cpu.pc),self.word('TICK')))
