"""Run cartridge instructions against recovered single-FIFO firmware handlers.

LOAD_TS/SAVE_TS/END_MSG are executed from the pinned public initial commit,
before they were ported to dual-port. Command dispatch is a documented model.
This is not execution of the frozen v1.00 bytecode or a hardware timing test.
"""
import ast
from collections import deque
import hashlib
import json
from pathlib import Path
import queue
import struct
import subprocess
import tempfile
import threading
import time
import types
import unittest

from test_cartridge import Machine, ROOT, UP, xor

COMMIT = 'b2758a5'
source = subprocess.check_output(
    ['git', '-C', str(UP), 'show', COMMIT+':src/TS/tspico_io.py'], text=True)
tree = ast.parse(source)
functions = [n for n in tree.body if isinstance(n, ast.FunctionDef)
             and n.name in ('LOAD_TS', 'SAVE_TS', 'END_MSG')]
assert len(functions) == 3
code = compile(ast.Module(body=functions, type_ignores=[]),
               'recovered-single-fifo-tspico_io.py', 'exec')


def tap_code(name, data, kind=3):
    header = bytes([kind])+name.encode().ljust(10, b' ')+len(data).to_bytes(2, 'little')+b'\x00\xa0\x00\x80'
    blocks = [bytes([0])+header, bytes([255])+data]
    return b''.join((len(b)+1).to_bytes(2, 'little')+b+bytes([xor(b)]) for b in blocks)


class MQ:
    def __init__(self):
        self.tx = queue.Queue(4)
        self.rx = queue.Queue(4)

    def put(self, value):
        if isinstance(value, str):
            value = value.encode()
        if isinstance(value, (bytes, bytearray)):
            for byte in value:
                self.put(byte)
        else:
            self.tx.put(value, timeout=5)

    def get(self):
        return self.rx.get(timeout=5)

    def tx_fifo(self):
        time.sleep(0)
        return self.tx.qsize()

    def rx_fifo(self):
        time.sleep(0)
        return self.rx.qsize()


class LegacyPico:
    def __init__(self, files=None, verbose=False, extra_ack=True, bad_crc=False):
        self.temp = tempfile.TemporaryDirectory(dir=ROOT/'build')
        self.root = Path(self.temp.name)
        self.files = dict(files or {'HELLO.TAP': tap_code('HELLO', b'Hello legacy.\r\n')})
        self.mq = MQ()
        self.pre = bytearray()
        self.worker = None
        self.errors = []
        self.traces = []
        self.extra_ack = extra_ack
        self.bad_crc = bad_crc
        self.cwd = '/sd/TAP'
        self.verbose = verbose
        self.empty_reads = 0
        self.tsp = types.SimpleNamespace(f_name='', totlen=0, offset=0,
                                        tap_idx=0, append=False,
                                        cur_path=self.cwd, LOG_LEVEL=0, VERBOSE=verbose)
        self.env = dict(MQ=self.mq, gc=types.SimpleNamespace(collect=lambda: None),
                        Pin=lambda *a: types.SimpleNamespace(value=lambda *a: None),
                        LOG_ADD=lambda *a: None, BLINK=lambda: None,
                        WATCHDOG=lambda *a: None, ABORT_TX=lambda *a: None,
                        _thread=types.SimpleNamespace(start_new_thread=lambda *a: None),
                        time=types.SimpleNamespace(ticks_us=lambda: int(time.monotonic()*1e6)),
                        os=types.SimpleNamespace(chdir=lambda *a: None),
                        open=self.open, ENA_SD=lambda: None,
                        busy=False, dead=False, kill=False)
        self.env['Pin'].OUT = 1
        exec(code, self.env)

    def open(self, path, mode):
        if path == '/TMP/temp.tap':
            path = '/mount.tap'
        return open(self.root/path.lstrip('/').replace('/', '_'), mode)

    def message(self, status=1, text='OK'):
        self.env['END_MSG'](self.mq, self.verbose, text, '', status)

    def directory(self):
        rows = [f'Path:{self.cwd[7:]}'.ljust(32), 'SD CARD'.ljust(32),
                'File Name                 Size'.ljust(32), '-'*32]
        prefix = self.cwd[8:]
        items = []
        dirs = set()
        for name in sorted(self.files):
            if prefix:
                if not name.startswith(prefix+'/'):
                    continue
                name = name[len(prefix)+1:]
            if '/' in name:
                dirs.add(name.split('/')[0])
            else:
                items.append(name)
        rows += [('<'+d+'>').ljust(22)+'       0 b' for d in sorted(dirs)]
        rows += [(f'{i:03} '+n.ljust(18))[:22]+f'{len(self.files[(prefix+"/" if prefix else "")+n]):10}'
                 for i, n in enumerate(items)]
        self.indices = items
        return ''.join(rows)

    def command(self, pre):
        self.mq.put(0x40)
        if self.extra_ack:
            self.mq.put(1)               # present in public legacy PROCESS_CMD
        length = pre[7]+256*pre[8]
        body = bytes(self.mq.get() for _ in range(length+4))
        assert body[:3] == b'D'+length.to_bytes(2, 'little') and xor(body) == 0
        self.traces.append((pre, body))
        cmd = body[3:-1].decode()
        rest = cmd[4:]
        if cmd.upper() == 'TPI:DIR':
            assert pre[1] == 1
            listing = self.directory()
            if len(listing) <= 672:
                self.env['END_MSG'](self.mq, True, listing, '', 1)
            else:
                self.mq.put(bytes([0x40, 0x86, 1, 13]))
                while listing:
                    page, listing = listing[:640], listing[640:]
                    prompt = 'press N to stop: ' if listing else '--- End of list (N to exit) ---'
                    self.mq.put(page+chr(13)+prompt+chr(13)+chr(0))
                    self.mq.put(0x40)
                    answer = self.mq.get()
                    if answer == ord('N'):
                        break
                    assert answer == ord('Y')
        elif cmd.upper() == 'TPI:CLOSE':
            self.tsp.f_name = ''
            self.tsp.append = False
            self.message()
        elif cmd.upper().startswith('TPI:CD '):
            assert pre[1] == 0
            folder = rest[3:]
            target = self.cwd
            if folder == '/':
                target = '/sd/TAP'
            elif folder == '..':
                target = self.cwd.rsplit('/', 1)[0] if self.cwd != '/sd/TAP' else self.cwd
            elif any(n.upper().startswith(((self.cwd[8:]+'/' if self.cwd[8:] else '')+folder+'/').upper()) for n in self.files):
                target += '/'+folder
            else:
                return self.message(3)
            self.cwd = target
            self.tsp.cur_path = target
            self.message()
        elif pre[1] == 1:
            prefix = self.cwd[8:]
            if rest.startswith('&'):
                self.directory()
                rest = self.indices[int(rest[1:])]
            key = (prefix+'/' if prefix else '')+rest
            match = next((n for n in self.files if n.upper() == key.upper()), None)
            if match is None:
                return self.message(3)
            data = self.files[match]
            if self.bad_crc:
                data = data[:-1]+bytes([data[-1]^1])
            with self.open('/TMP/temp.tap', 'wb') as f:
                f.write(data)
            self.tsp.f_name = '/sd/TAP/'+match
            self.tsp.offset = self.tsp.tap_idx = 0
            self.tsp.totlen = len(data)
            self.message()
        else:
            self.message(5)

    def run(self, pre):
        try:
            assert len(pre) == 10 and xor(pre) == 0
            self.mq.put(1)
            if pre[0] == ord('B'):
                self.command(pre)
            elif pre[1] == 1:
                self.env['LOAD_TS'](pre, self.mq, self.tsp)
            else:
                self.env['SAVE_TS'](self.mq, self.tsp)
                for file in self.root.glob('sd_TAP_*.tap'):
                    self.files[file.name[len('sd_TAP_'):].replace('_FOLDER_', '/FOLDER/')] = file.read_bytes()
        except BaseException as error:
            self.errors.append(repr(error))

    def port_out(self, port, value):
        assert port == 14, 'legacy must never write status/SYNC port'
        if self.worker and self.worker.is_alive():
            self.mq.rx.put(value, timeout=5)
            return
        if self.worker:
            assert not self.errors, self.errors
            self.worker.join()
            self.worker = None
        self.pre.append(value)
        if len(self.pre) == 10:
            pre, self.pre = bytes(self.pre), bytearray()
            self.worker = threading.Thread(target=self.run, args=(pre,), daemon=True)
            self.worker.start()

    def port_in(self, port):
        assert port in (14, 15)
        try:
            value = self.mq.tx.get(timeout=getattr(self, 'host_read_timeout', .01))
            self.empty_reads = 0
            return value
        except queue.Empty:
            assert not self.errors, self.errors
            self.empty_reads += 1
            assert self.empty_reads < 50, ('stalled modeled FIFO', self.mq.rx.qsize(), self.traces[-1:] )
            return 0

    def clean(self):
        if self.worker:
            self.worker.join(timeout=1)
            assert not self.worker.is_alive(), 'handler stuck'
        assert not self.errors, self.errors
        assert self.mq.tx.empty() and self.mq.rx.empty() and not self.pre

    def close(self):
        self.clean()
        self.temp.cleanup()


class LegacyMachine(Machine):
    def __init__(self, **kw):
        super().__init__('filebrowse-legacy')
        self.pico = LegacyPico(**kw)
        self.fast_delay = True
        self.read_start = None
        self.read_ticks = []

    def fetch(self, a):
        super().fetch(a)
        if a == self.syms['legacy_read_block.read'] and self.read_start is None:
            self.read_start = self.cpu.t
        if a == self.syms['legacy_read_block.crc'] and self.read_start is not None:
            self.read_ticks.append(self.cpu.t-self.read_start)
            self.read_start = None
        if getattr(self, 'fast_delay', False) and a == self.syms['legacy_settle.inner']:
            # Fast-forward only the pure busy delay. Leave protocol and UI
            # instructions untouched; test the real delay separately below.
            assert self.cpu.get_rp(0) == 0
            self.cpu.a = 0
            self.cpu.f = 0x44
            self.cpu.t += 65536*26-5
            self.cpu.pc += 5
            if self.pico.worker:
                self.pico.worker.join(timeout=.1)

    def link_ok(self):
        self.pico.clean()


class LegacyTests(unittest.TestCase):
    def setUp(self):
        self.machines = []

    def machine(self, **kw):
        m = LegacyMachine(**kw)
        self.machines.append(m)
        return m

    def tearDown(self):
        for m in self.machines:
            m.pico.close()

    def test_original_100_firmware_evidence(self):
        uf2 = (ROOT/'references/TS-Pico/firmware/tspicofirmware v1.uf2').read_bytes()
        self.assertEqual(hashlib.sha256(uf2).hexdigest(),
                         '20350721dbc473bac2c4a35c85fe2607d94776cf9fecf9bc55ff6b26dfac7573')
        pieces = []
        for offset in range(0, len(uf2), 512):
            m0, m1, flags, target, length, number, total, family = struct.unpack_from('<8I', uf2, offset)
            self.assertEqual((m0, m1), (0x0a324655, 0x9e5d5157))
            self.assertEqual(struct.unpack_from('<I', uf2, offset+508)[0], 0x0ab16f30)
            self.assertLessEqual(length, 476)
            pieces.append((target, uf2[offset+32:offset+32+length]))
        lo = min(a for a, b in pieces)
        hi = max(a+len(b) for a, b in pieces)
        image = bytearray(b'\xff'*(hi-lo))
        for address, payload in pieces:
            image[address-lo:address-lo+len(payload)] = payload
        for marker in (b'MicroPython v1.20.0; TS-Pico firmware v1.0 on 2023-11-23',
                       b'TPI:DIR', b'TPI:CD ', b'TPI:CLOSE', b'LOAD_TS', b'SAVE_TS',
                       b'%03d', b'%-18s', b'--- End of list (N to exit) ---'):
            self.assertIn(marker, image)

    def test_full_buffer_watchdog_budget(self):
        data = bytes(range(256))*64
        m = self.machine(files={'BIG.TAP': tap_code('BIG', data)})
        m.string('SELECTED_PATH', 'BIG.TAP')
        self.assertFalse(m.call('f_load', hl=m.syms['SELECTED_PATH'], de=0xa000, bc=16384).cf)
        self.assertEqual(bytes(m.mem[0xa000:0xe000]), data)
        self.assertLess(m.read_ticks[-1]/3528000, 2.5)
        print(f'\nlegacy 16 KB data loop: {m.read_ticks[-1]/3528000:.3f}s Z80 time, Pico latency excluded')
    def test_real_settle_loop(self):
        m = self.machine()
        m.fast_delay = False
        before = m.cpu.t
        m.call('legacy_settle', bc=0x1234, de=0x5678)
        self.assertEqual(m.cpu.get_rp(0), 0x1234)
        self.assertEqual(m.cpu.get_rp(1), 0x5678)
        self.assertGreater((m.cpu.t-before)/3528000, 2.3)
    def test_binary_load_recovered_handler(self):
        for verbose in (False, True):
            data = bytes(range(256))*4
            m = self.machine(files={'BYTES.TAP': tap_code('BYTES', data)}, verbose=verbose)
            m.string('SELECTED_PATH', 'BYTES.TAP')
            c = m.call('f_load', hl=m.syms['SELECTED_PATH'], de=0xa000, bc=16384)
            self.assertFalse(c.cf, hex(c.a))
            self.assertEqual(m.word('FILE_DONE'), len(data))
            self.assertEqual(bytes(m.mem[0xa000:0xa000+len(data)]), data)
            m.link_ok()

    def test_save_recovered_handler_all_bytes_and_zero_length(self):
        for data in (bytes(range(256))*4, b''):
            m = self.machine(verbose=True)
            m.mem[0xa000:0xa000+len(data)] = data
            m.string('SELECTED_PATH', 'COPY')
            m.pico.tsp.f_name = '/sd/TAP/OLD.tap'
            m.pico.tsp.append = True
            c = m.call('f_save', hl=m.syms['SELECTED_PATH'], de=0xa000, bc=len(data))
            self.assertFalse(c.cf, hex(c.a))
            self.assertEqual(m.word('FILE_DONE'), len(data))
            m.link_ok()
            self.assertEqual(m.pico.files['COPY.tap'], tap_code('COPY', data))
            m.string('SELECTED_PATH', 'COPY.TAP')
            self.assertFalse(m.call('f_load', hl=m.syms['SELECTED_PATH'], de=0xa000, bc=16384).cf)
            self.assertEqual(m.word('FILE_DONE'), len(data))
            m.link_ok()

    def test_directory_single_and_multiple_pages(self):
        for count in (1, 42, 220):
            m = self.machine(files={f'FILE{i:03}.TAP': tap_code('DEMO', b'123') for i in range(count)})
            c = m.call('legacy_directory')
            self.assertEqual(c.cf, count == 220)
            captured = m.string(m.syms['LEGACY_REPLY_BUFFER'])
            self.assertIn('FILE000.TAP', captured)
            if count == 42:
                self.assertIn('FILE041.TAP', captured)
            self.assertLessEqual(m.word('LEGACY_USED'), m.syms['LEGACY_REPLY_CAPACITY']-1)
            m.link_ok()

    def test_refuse_capacity_type_missing_and_bad_checksum(self):
        for data, capacity, kind, corrupt, expected in (
                (b'x'*30, 10, 3, False, 0xe4),
                (b'x', 10, 2, False, 0xe3),
                (b'x', 10, 3, True, 0xe2)):
            m = self.machine(files={'TEST.TAP': tap_code('TEST', data, kind)}, bad_crc=corrupt)
            m.string('SELECTED_PATH', 'TEST.TAP')
            c = m.call('f_load', hl=m.syms['SELECTED_PATH'], de=0xa000, bc=capacity)
            self.assertTrue(c.cf)
            self.assertEqual(c.a, expected)
            self.assertEqual(m.word('FILE_DONE'), 0)
            m.link_ok()
        m = self.machine()
        m.string('SELECTED_PATH', 'MISSING.TAP')
        c = m.call('f_load', hl=m.syms['SELECTED_PATH'], de=0xa000, bc=16384)
        self.assertTrue(c.cf)
        self.assertEqual(c.a, 3)
        m.link_ok()

    def test_no_extra_command_ack_and_bad_save_names(self):
        m = self.machine(extra_ack=False)
        self.assertFalse(m.call('legacy_directory').cf)
        m.link_ok()
        for name in ('', 'TOOLONGNAME', 'X.TAP', '../X', 'BAD NAME'):
            m.string('SELECTED_PATH', name)
            c = m.call('f_save', hl=m.syms['SELECTED_PATH'], de=0xa000, bc=0)
            self.assertTrue(c.cf)
            self.assertEqual(c.a, 0xe6)
        self.assertEqual(len(m.pico.traces), 1)

    def test_keyboard_browser_load_save_cancel(self):
        m = self.machine(files={'FOLDER/HELLO.TAP': tap_code('HELLO', b'Legacy text\r\n')})
        m.ui('', start=True)
        m.screenshot('legacy-home')
        m.ui('OCFOLDER\r')
        m.screenshot('legacy-directory')
        m.ui('O000\r')
        self.assertEqual(m.word('BUFFER_LEN'), 13)
        m.screenshot('legacy-preview')
        m.ui('SCOPY\rY')
        m.screenshot('legacy-saved')
        m.ui('XO BX'.replace(' ', ''))

    def test_unsupported_channels_and_aros_handoff(self):
        m = self.machine()
        for label in ('f_open', 'f_read', 'f_write', 'f_close'):
            c = m.call(label)
            self.assertTrue(c.cf)
            self.assertEqual(c.a, 0xe3)
        m.hsr = 16
        m.cpu.pc = 0x8008
        m.ui('')
        self.assertEqual(m.hsr, 3)
        self.assertEqual(m.cpu.sp, 0xffee)  # inside the keyboard CALL


if __name__ == '__main__':
    program = unittest.main(exit=False)
    result = program.result
    report = dict(passed=result.wasSuccessful(), tests=result.testsRun,
                  firmware_handler_source=COMMIT+':src/TS/tspico_io.py',
                  source_sha256=hashlib.sha256(source.encode()).hexdigest(),
                  command_dispatch='modeled; not frozen v1.00 bytecode execution',
                  hardware_tested=False,
                  images={'filebrowse-legacy': hashlib.sha256((ROOT/'build/filebrowse-legacy.dck').read_bytes()).hexdigest()})
    (ROOT/'build/legacy-validation.json').write_text(json.dumps(report, indent=2)+'\n')
    raise SystemExit(not result.wasSuccessful())
