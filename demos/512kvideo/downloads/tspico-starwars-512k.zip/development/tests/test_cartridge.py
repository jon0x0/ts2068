"""Execute built Z80 instructions against the upstream Pico/channel model.

No system ROM is loaded. ROM writes and opcode fetches outside our image fail.
This is functional host evidence, not a cycle-accurate bus or hardware test.
"""
from pathlib import Path
import importlib.util
import json
import sys
import unittest
import ast
import tempfile
import gc
import os
import builtins
import types

ROOT = Path(__file__).resolve().parents[1]
UP = ROOT/'references/tspico-firmware-build'
sys.path.insert(0, str(ROOT/'scripts'))
from build import symbols
spec = importlib.util.spec_from_file_location('upstream_examples', UP/'docs/manual/examples/test_examples.py')
up = importlib.util.module_from_spec(spec)
# The imported upstream test module treats argv[1] as a repo path.
saved_argv = sys.argv[:]
sys.argv = [str(spec.origin), str(UP)]
spec.loader.exec_module(up)
sys.argv = saved_argv
from z80core import Z80
from PIL import Image


def directory_handler(p, pre, cmd):
    stream, reclen = up.params(pre)
    arg = up.args(cmd).strip()
    mode, path = arg.split(' ', 1)
    if not path.lower().startswith('d:'):
        return up.h_chopen(p, pre, cmd)
    where, pat = up.catalog.split_arg(path[2:])
    real = up.catalog.resolve(p.cur, where)
    if not real or (real != up.catalog.ROOT and not any(n.startswith(real+'/') for n in p.fs.files)):
        return up.ch_reply(p, 3)
    entries = {}
    for path, data in p.fs.files.items():
        if not path.startswith(real+'/'):
            continue
        rest = path[len(real)+1:]
        name = rest.split('/')[0]
        isdir = '/' in rest
        entries[name] = (name, 16384 if isdir else 32768, 0, len(data))
    names = [n+('/' if d else '') for n, d, size in up.catalog.select(entries.values(), pat)]
    p.ch.open_list(stream & 255, names)
    up.ch_reply(p, 1)


class Pico(up.Pico):
    def __init__(self, files=None, **kw):
        super().__init__(files, **kw)
        self.traces = []

    def process(self, body):
        # Validate both framing layers independently of the Z80 construction.
        assert len(self.pre) == 10 and self.pre[0] == 0x42 and self.pre[1] == 0
        assert not xor(self.pre)
        assert body[1]+256*body[2] == self.pre[7]+256*self.pre[8]
        assert not xor(body)
        self.traces.append((bytes(self.pre), bytes(body)))
        return super().process(body)


def xor(data):
    x = 0
    for b in data:
        x ^= b
    return x


up.HANDLERS['TPI:CHOPEN'] = directory_handler


class Machine:
    def __init__(self, name='filebrowse', files=None, verbose=False):
        self.name = name
        self.syms = symbols(ROOT/f'build/{name}.sym')
        self.image = (ROOT/f'build/{name}.bin').read_bytes()
        self.mem = bytearray(65536)
        self.base = (0xc000 if name in ("ram512","ram512b","ram512c","sw512") else 0xd800 if name in ('full160-ram','full160-v5','full160-v6','full160-v7','sparse-v8','stream9','transfer-bench-r3','transfer-bench') else
                     (0xe000 if name == 'video160-ram' else (0x1000 if name.startswith('filelib') else 0)))
        self.mem[self.base:self.base+len(self.image)] = self.image
        self.flat = (ROOT/f'build/{name}-64k.bin').read_bytes() if self.base == 0 else None
        self.pico = Pico(files, verbose=verbose)
        self.hsr = 0 if self.base in (0xd800,0xe000) else 3
        self.decr = 0x40
        self.held = set()
        self.keys = []
        self.writes = []
        self.io_times = []
        self.ui_active = False
        self.cpu = Z80(self.read, self.write, self.port_in, self.port_out)
        self.cpu.fetch_hook = self.fetch

    def read(self, a):
        # Low chunks must continue to be DOCK; no replacement HOME ROM exists.
        if a < 0x4000 and self.base == 0:
            assert self.hsr & (1 << (a//8192)), hex(a)
            assert not self.decr & 0x80
        if self.base == 0 and self.hsr & (1 << (a//8192)):
            return self.flat[a]
        return self.mem[a]

    def write(self, a, v):
        assert a >= 0x4000, f'write to cartridge ROM {a:04x}'
        if self.base == 0:
            assert not self.hsr & (1 << (a//8192)), f'write to mapped cartridge {a:04x}'
        self.mem[a] = v
        self.writes.append(a)

    def fetch(self, a):
        bootstrap = self.base == 0 and self.hsr & 16 and 0x8008 <= a < 0x8013
        assert bootstrap or self.base <= a < self.base+len(self.image), f'non-cartridge fetch {a:04x}'
        if self.ui_active:
            if a == self.syms['key_get']:
                self.held = set()
            if a == self.syms['key_get.press']:
                if not self.keys:
                    raise StopIteration
                key = self.keys.pop(0)
                self.held = matrix_key(key)

    def port_in(self, port):
        p = port & 255
        if p in (14, 15):
            self.io_times.append((self.cpu.t, 'in', p))
            return self.pico.port_in(p)
        if p == 0xfe:
            value = 255
            for row, bit in self.held:
                if not (port >> (8+row)) & 1:
                    value &= ~(1 << bit)
            return value
        return 255

    def port_out(self, port, value):
        p = port & 255
        if p in (14, 15):
            self.io_times.append((self.cpu.t, 'out', p))
            self.pico.port_out(p, value)
        elif p == 0xf4:
            self.hsr = value
        elif p == 0xff:
            self.decr = value

    def word(self, name, value=None):
        a = self.syms.get(name, name)
        if value is not None:
            self.mem[a:a+2] = value.to_bytes(2, 'little')
        return int.from_bytes(self.mem[a:a+2], 'little')

    def string(self, name, value=None):
        a = self.syms.get(name, name)
        if value is not None:
            self.mem[a:a+len(value)+1] = value.encode()+b'\0'
        return bytes(self.mem[a:self.mem.index(0,a)]).decode()

    def call(self, label, a=0, bc=0, de=0, hl=0, max_steps=3_000_000):
        cpu = self.cpu
        cpu.a = a
        cpu.set_rp(0, bc)
        cpu.set_rp(1, de)
        cpu.set_rp(2, hl)
        cpu.sp = 0xff00
        cpu.push(0xfffe)
        cpu.pc = self.syms[label]
        for _ in range(max_steps):
            if cpu.pc == 0xfffe:
                assert cpu.sp == 0xff00
                return cpu
            cpu.step()
        raise AssertionError(f'{label} did not return, pc={cpu.pc:04x}')

    def link_ok(self):
        assert self.pico.underruns == self.pico.stray == 0
        assert list(self.pico.tx) == [1]
        assert self.pico.state == 'idle'

    def ui(self, keys='', start=False):
        self.keys = list(keys)
        self.ui_active = True
        if start:
            self.cpu.pc = self.syms['start']
        try:
            for _ in range(4_000_000):
                self.cpu.step()
            raise AssertionError('UI did not reach keyboard wait')
        except StopIteration:
            pass
        self.assert_keys_consumed = not self.keys
        assert not self.keys
        self.link_ok()

    def screenshot(self, name):
        palette = [(0,0,0),(0,0,205),(205,0,0),(205,0,205),
                   (0,205,0),(0,205,205),(205,205,0),(205,205,205)]
        bright = [(0,0,0),(0,0,255),(255,0,0),(255,0,255),
                  (0,255,0),(0,255,255),(255,255,0),(255,255,255)]
        im = Image.new('RGB',(256,192))
        for y in range(192):
            row = 0x4000+((y&0xc0)<<5)+((y&7)<<8)+((y&0x38)<<2)
            for x in range(256):
                attr = self.mem[0x5800+(y//8)*32+x//8]
                pal = bright if attr&64 else palette
                colour = attr&7 if self.mem[row+x//8]&(0x80>>(x&7)) else (attr>>3)&7
                im.putpixel((x,y),pal[colour])
        im.resize((768,576),Image.Resampling.NEAREST).save(ROOT/f'build/{name}.png')


def matrix_key(key):
    if key == '.':
        return {(7,1),(7,2)}
    if key == '\x1b':
        return {(0,0),(7,0)}
    if key == '\x08':
        return {(0,0),(4,0)}
    rows = ['\x01ZXCV','ASDFG','QWERT','12345','09876','POIUY','\rLKJH',' \x02MNB']
    for row, chars in enumerate(rows):
        if key in chars:
            return {(row,chars.index(key))}
    raise ValueError(key)


class CartridgeTests(unittest.TestCase):
    def test_actual_firmware_expands_virtual_dock_image(self):
        source = UP/'src/TS/tspico.py'
        tree = ast.parse(source.read_text(encoding='utf-8'))
        fn = next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name == 'DCK_IMAGE')
        module = ast.Module(body=[fn],type_ignores=[])
        for name in ('filebrowse','filebrowse-stream'):
            with tempfile.TemporaryDirectory(dir=ROOT/'build') as temp:
                folder = Path(temp)
                def mapped(path):
                    self.assertTrue(path.startswith('/TMP/'))
                    return folder/Path(path).name
                env = {'gc':gc,'LOG':lambda *a:None,
                       'open':lambda path,mode:builtins.open(mapped(path),mode),
                       'os':types.SimpleNamespace(remove=lambda p:os.remove(mapped(p)),
                                                  rename=lambda a,b:os.rename(mapped(a),mapped(b)))}
                (folder/'temp.bin').write_bytes((ROOT/f'build/{name}.dck').read_bytes())
                exec(compile(module,str(source),'exec'),env)
                self.assertTrue(env['DCK_IMAGE']())
                expanded = (folder/'temp.bin').read_bytes()
                flat = (ROOT/f'build/{name}-64k.bin').read_bytes()
                self.assertEqual(len(expanded),65536)
                for chunk in (0,1,4):
                    self.assertEqual(expanded[chunk*8192:(chunk+1)*8192],
                                     flat[chunk*8192:(chunk+1)*8192])
                for chunk in (2,3,5,6,7):
                    self.assertEqual(expanded[chunk*8192:(chunk+1)*8192],bytes(8192))

    def test_aros_handoff_both_profiles(self):
        for name in ('filebrowse','filebrowse-stream'):
            m = Machine(name)
            m.hsr = 0x10
            m.cpu.pc = 0x8008
            m.cpu.sp = 0x61fe
            m.ui()
            self.assertEqual(m.hsr,3)
            self.assertEqual(m.decr,0x40)
            self.assertEqual(m.cpu.sp,0xffee)  # inside call key_get
            self.assertFalse(m.cpu.iff)

    def test_full_keyboard_browser_load_save_dialog(self):
        data = b'Hello from the file browser.\r\n'*30
        m = Machine(files={'/sd/TAP/DOCS/LETTER.TXT':data, '/sd/TAP/ROOT.TXT':b'root'})
        m.ui(start=True)
        m.screenshot('demo-home')
        self.assertEqual(m.hsr,3)
        self.assertEqual(m.decr,0x40)
        self.assertFalse(m.cpu.iff)
        m.ui('O')
        m.screenshot('demo-browser')
        self.assertEqual(m.string(0x8000),'DOCS/')
        m.ui('\r')
        self.assertEqual(m.string('PATH_BUFFER'),'/DOCS/')
        m.ui('\r')
        m.screenshot('demo-preview')
        self.assertEqual(m.word('BUFFER_LEN'),len(data))
        m.ui('S')
        m.ui('COPY.TXT\r')
        m.screenshot('demo-save-confirm')
        self.assertNotIn('/sd/TAP/DOCS/COPY.TXT',m.pico.fs.files)
        m.ui('Y')
        self.assertEqual(bytes(m.pico.fs.files['/sd/TAP/DOCS/COPY.TXT']),data)
        m.ui('O')
        m.ui('B')
        self.assertEqual(m.string('PATH_BUFFER'),'/')
        m.ui('X')
        self.assertEqual(m.word('BUFFER_LEN'),len(data))

    def test_packaging_and_optional_link(self):
        for name in ('filebrowse','filebrowse-stream'):
            dck = (ROOT/f'build/{name}.dck').read_bytes()
            flat = (ROOT/f'build/{name}-64k.bin').read_bytes()
            self.assertEqual(dck[:9], bytes([0,2,2,0,0,2,0,0,0]))
            self.assertEqual(len(dck), 9+3*8192)
            self.assertEqual(len(flat),65536)
            self.assertEqual(dck[9:9+16384],flat[:16384])
            self.assertEqual(flat[:2],bytes.fromhex('00ff'))
            self.assertEqual(flat[0x8000:0x8008],bytes.fromhex('02020880ef010000'))
        core = Machine('filelib')
        stream = Machine('filelib-stream')
        self.assertNotIn('stream_get',core.syms)
        self.assertIn('stream_get',stream.syms)
        self.assertGreater(len(stream.image),len(core.image))

    def test_read_binary_all_values_and_exact_capacity(self):
        data = bytes(range(256))*4
        for cap in (len(data), len(data)+5):
            m = Machine(files={'/sd/TAP/bytes.bin':data})
            m.string('SELECTED_PATH','/bytes.bin')
            m.mem[0xa000+cap] = 0xa5
            cpu = m.call('f_load',hl=m.syms['SELECTED_PATH'],de=0xa000,bc=cap)
            self.assertFalse(cpu.cf)
            self.assertEqual(m.mem[0xa000:0xa000+len(data)],data)
            self.assertEqual(m.mem[0xa000+cap],0xa5)
            self.assertEqual(m.word('FILE_DONE'),len(data))
            self.assertEqual(m.pico.ch.table,{})
            m.link_ok()

    def test_partial_capacity_and_missing_file_cleanup(self):
        m = Machine(files={'/sd/TAP/big.bin':b'x'*700})
        m.string('SELECTED_PATH','/big.bin')
        m.mem[0xa200] = 0xa5
        c = m.call('f_load',hl=m.syms['SELECTED_PATH'],de=0xa000,bc=512)
        self.assertTrue(c.cf)
        self.assertEqual(c.a,m.syms['E_CAPACITY'])
        self.assertEqual(m.word('FILE_DONE'),512)
        self.assertEqual(m.mem[0xa200],0xa5)
        self.assertEqual(m.pico.ch.table,{})
        m.string('SELECTED_PATH','/missing')
        c = m.call('f_load',hl=m.syms['SELECTED_PATH'],de=0xa000,bc=512)
        self.assertTrue(c.cf)
        self.assertEqual(c.a,3)
        m.link_ok()

    def test_save_reopen_and_reserved_preflight(self):
        m = Machine(files={'/sd/TAP/existing':b'original'})
        m.string('SELECTED_PATH','/existing')
        data = bytes(i for i in range(256) if i != 23)*3
        m.mem[0xa000:0xa000+len(data)] = data
        c = m.call('f_save',hl=m.syms['SELECTED_PATH'],de=0xa000,bc=len(data))
        self.assertFalse(c.cf)
        self.assertEqual(bytes(m.pico.fs.files['/sd/TAP/existing']),data)
        before = len(m.pico.commands)
        m.mem[0xa000:0xa004] = b'A\x17BC'
        c = m.call('f_save',hl=m.syms['SELECTED_PATH'],de=0xa000,bc=4)
        self.assertTrue(c.cf)
        self.assertEqual(c.a,m.syms['E_RESERVED_BYTE'])
        self.assertEqual(len(m.pico.commands),before)
        self.assertEqual(bytes(m.pico.fs.files['/sd/TAP/existing']),data)
        m.link_ok()
        c = m.call('f_save',hl=m.syms['SELECTED_PATH'],de=0xa000,bc=0)
        self.assertFalse(c.cf)
        self.assertEqual(bytes(m.pico.fs.files['/sd/TAP/existing']),b'')
        m.link_ok()

    def test_directory_navigation_and_limits(self):
        files = {'/sd/TAP/Folder/inside.txt':b'inside','/sd/TAP/root.bin':b'root'}
        m = Machine(files=files)
        m.string('PATH_BUFFER','/')
        c = m.call('dir_refresh')
        self.assertFalse(c.cf)
        self.assertEqual(m.mem[m.syms['DIR_COUNT']],2)
        self.assertEqual(m.string(0x8000),'Folder/')
        c = m.call('dialog_enter')
        self.assertFalse(c.cf)
        self.assertEqual(c.a,1)
        self.assertEqual(m.string('PATH_BUFFER'),'/Folder/')
        self.assertEqual(m.string(0x8000),'inside.txt')
        c = m.call('dialog_enter')
        self.assertFalse(c.cf)
        self.assertEqual(c.a,0)
        self.assertEqual(m.string('SELECTED_PATH'),'/Folder/inside.txt')
        self.assertFalse(m.call('dialog_parent').cf)
        self.assertEqual(m.string('PATH_BUFFER'),'/')
        self.assertFalse(m.call('dialog_parent').cf)
        self.assertEqual(m.string('PATH_BUFFER'),'/')
        m.link_ok()
        files = {f'/sd/TAP/F{i:03}.bin':b'x' for i in range(110)}
        files['/sd/TAP/'+'A'*80+'.bin'] = b'long'
        m = Machine(files=files)
        m.string('PATH_BUFFER','/')
        m.mem[0x9800] = 0xa5
        self.assertFalse(m.call('dir_refresh').cf)
        self.assertEqual(m.mem[m.syms['DIR_COUNT']],96)
        self.assertEqual(m.mem[m.syms['DIR_TRUNC']],1)
        self.assertEqual(m.mem[0x9800],0xa5)
        self.assertLess(len(m.string(0x8000)),64)
        m.link_ok()

    def test_transport_verbose_and_corruption(self):
        m = Machine(verbose=True)
        m.string('COMMAND_BUFFER','tpi:path')
        self.assertFalse(m.call('tpi_execute',hl=m.syms['COMMAND_BUFFER']).cf)
        m.link_ok()
        m = Machine(files={'/sd/TAP/a':b'abc'})
        m.string('SELECTED_PATH','/a')
        original = m.pico.process
        def corrupt(body):
            original(body)
            if m.pico.commands[-1] == 'tpi:chrd' and len(m.pico.tx) > 3:
                m.pico.tx[-1] ^= 1
        m.pico.process = corrupt
        c = m.call('f_load',hl=m.syms['SELECTED_PATH'],de=0xa000,bc=20)
        self.assertTrue(c.cf)
        self.assertEqual(c.a,m.syms['E_CHECKSUM'])
        self.assertEqual(m.pico.ch.table,{})
        m.link_ok()

    def test_no_device_timeout(self):
        m = Machine()
        m.pico.port_in = lambda p: 0
        m.string('COMMAND_BUFFER','tpi:nop')
        c = m.call('tpi_execute',hl=m.syms['COMMAND_BUFFER'])
        self.assertTrue(c.cf)
        self.assertEqual(c.a,m.syms['E_TIMEOUT'])

    def test_stream_exceeds_ram_and_keeps_all_byte_values(self):
        data = bytes(range(256))*100
        m = Machine('filebrowse-stream',files={'/sd/TAP/video.bin':data})
        m.string('SELECTED_PATH','/video.bin')
        self.assertFalse(m.call('stream_open',hl=m.syms['SELECTED_PATH']).cf)
        got = bytearray()
        t0 = m.cpu.t
        for _ in range(len(data)+1):
            c = m.call('stream_get')
            if c.cf:
                self.assertEqual(c.a,7)
                break
            got.append(c.a)
        self.assertEqual(got,data)
        self.assertEqual(int.from_bytes(m.mem[m.syms['STREAM_TOTAL']:m.syms['STREAM_TOTAL']+4],'little'),len(data))
        self.assertEqual(m.pico.ch.table,{})
        m.link_ok()
        elapsed = m.cpu.t-t0
        print(f'\nstream host timing: {len(data)} bytes, {elapsed} T, {len(data)*3528000/elapsed:.0f} B/s (Pico latency excluded)')

    def test_keyboard_matrix(self):
        m = Machine()
        for held, want in [({(2,0)},ord('Q')),({(6,0)},13),({(7,1),(7,2)},ord('.')),
                           ({(0,0),(4,0)},8),({(0,0),(7,0)},27), (set(),0)]:
            m.held = held
            self.assertEqual(m.call('key_scan').a,want)


if __name__ == '__main__':
    program = unittest.main(exit=False)
    result = program.result
    report = {'tests': result.testsRun, 'passed': result.wasSuccessful(),
              'failures': [str(t) for t, _ in result.failures],
              'errors': [str(t) for t, _ in result.errors],
              'model': 'upstream TPI protocol model + real channels.py/catalog.py',
              'firmware_commit': '6b72847e1121112e438d6d4c2ec41835df90f940',
              'system_rom_loaded_in_host_tests': False,
              'hardware_tested': False}
    import hashlib
    report['images'] = {n:hashlib.sha256((ROOT/f'build/{n}.dck').read_bytes()).hexdigest()
                        for n in ('filebrowse','filebrowse-stream')}
    (ROOT/'build/host-validation.json').write_text(json.dumps(report,indent=2)+'\n')
    raise SystemExit(0 if result.wasSuccessful() else 1)
