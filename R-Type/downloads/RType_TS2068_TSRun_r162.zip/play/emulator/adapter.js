// R-Type cartridge personalization integration around TSRun's live public modules.
// Upstream: https://github.com/josef-jelinek/TSRun
const upstream=new URL('../tsrun/',import.meta.url).href;
const frameMs=1000*58688/3528000;
function notify(type,message){window.parent.postMessage({type,message},location.origin);}
async function resource(path,binary=false){
  const response=await fetch(path);
  if(!response.ok)throw new Error(`Could not load ${path}: HTTP ${response.status}`);
  return binary?new Uint8Array(await response.arrayBuffer()):response.text();
}
async function boot(){
  const [cpu,video,sound,keys,pads]=await Promise.all(
    ['machine.js','screen.js','sound.js','keyboard.js','joystick.js'].map(path=>import(upstream+path)));
  const canvas=document.getElementById('screen');
  const matrix=new Uint8Array(8),joystick=new Uint8Array(2);
  const kbd=keys.initKeyboard(document.getElementById('keyboard'),matrix);
  pads.initJoysticks(joystick);
  const machine=cpu.createMachine(matrix,joystick);
  const [rom0,rom1,cartridge,vert,frag]=await Promise.all([
    resource(upstream+'roms/ts2068-0.rom',true),resource(upstream+'roms/ts2068-1.rom',true),
    resource(`../assets/rt_l${Math.max(1,Math.min(8,Number(new URLSearchParams(location.search).get('level'))||1))}_r162.dck`,true),
    resource(upstream+'screen.vert.glsl'),resource(upstream+'screen.frag.glsl')]);
  if(rom0.length!==16384||rom1.length!==8192)throw new Error('Unexpected TS2068 system ROM sizes.');
  machine.homeRom.set(rom0);machine.exRom.set(rom1);
  const cartError=cpu.insertDock(machine,cartridge);
  if(cartError)throw new Error(cartError);
  cpu.resetMachine(machine);
  let gfx=null;
  await new Promise((resolve,reject)=>video.initScreen(canvas,{vert,frag},(err,value)=>{
    if(err||!value){reject(new Error(err||'WebGL2 unavailable'));notify('rtype-error',err);return;}
    gfx=value;video.setCrt(gfx,false);resolve();
  }));
  const sfx=await new Promise((resolve,reject)=>sound.initSound(1000/frameMs,(err,value)=>{
    if(err||!value)reject(new Error(err||'Web Audio unavailable'));else resolve(value);
  }));
  const output=sfx.context.createGain();
  sfx.node.disconnect();sfx.node.connect(output);output.connect(sfx.context.destination);
  cpu.setSoundRate(machine,sfx.context.sampleRate);cpu.enableSound(machine,true);sound.setSoundStereo(sfx,false);
  let last=0,carry=frameMs,started=false,touch=255;
  function step(){
    cpu.runFrame(machine);
    const chunk=cpu.takeAudio(machine);
    if(chunk.n>0&&(sound.soundIsRunning(sfx)||sound.soundWantsFrame(sfx)))sound.pushSound(sfx,chunk);
  }
  function frame(now){
    requestAnimationFrame(frame);
    pads.pollJoysticks(joystick);
    joystick[0]&=touch;
    if(!last)last=now;
    carry+=Math.min(80,now-last);last=now;
    let ran=0;
    while(carry>=frameMs&&ran<4){step();carry-=frameMs;ran++;}
    if(started&&sound.soundIsRunning(sfx)&&sound.soundWantsFrame(sfx)&&ran<4){step();carry=Math.max(carry,0)-frameMs;}
    video.drawScreen(gfx,machine.pixels);
  }
  window.rtype={
    setSound(on){output.gain.value=on?1:0;this.start();},
    setCrt(on){video.setCrt(gfx,on);},
    key(event,down){this.start();(down?keys.handleKeyDown:keys.handleKeyUp)(kbd,event);},
    contacts(value){touch=value;this.start();},
    release(){touch=255;keys.handleBlur(kbd);},
    start(){started=true;sound.resumeSound(sfx);return true;},
    press(code,duration=120){
      this.start();const event={code,preventDefault(){},repeat:false};
      keys.handleKeyDown(kbd,event);setTimeout(()=>keys.handleKeyUp(kbd,event),duration);
    },
    async sequence(codes){
      if(codes.join(',')!=='KeyB,KeyB'){for(const code of codes){this.press(code,500);await new Promise(r=>setTimeout(r,1000));}return;}
      // Acknowledge the native chord latch; do not edit game state or rely on FPS.
      this.start();this.release();
      const wait=async(test)=>{for(let n=0;n<160;n++){if(test())return true;await new Promise(r=>setTimeout(r,50));}return false;};
      if(!await wait(()=>machine.ram[0x7aa4]>=2&&machine.ram[0x7aa4]<=4&&[0,2].includes(machine.ram[0xfd4b]))){notify('rtype-command','Start the game before using Boss.');return;}
      const e={code:'KeyB',preventDefault(){},repeat:false};
      if(machine.ram[0xfd4b]===0){
        keys.handleKeyDown(kbd,e);const seen=await wait(()=>machine.ram[0xfd4b]===1);keys.handleKeyUp(kbd,e);
        if(!seen||!await wait(()=>machine.ram[0xfd4b]===2))return;
      }
      keys.handleKeyDown(kbd,e);await wait(()=>machine.ram[0xfd4b]!==2);keys.handleKeyUp(kbd,e);
    },
    chord(code){this.start();const e={code,preventDefault(){},repeat:false},s={...e,code:'ShiftLeft'};keys.handleKeyDown(kbd,s);keys.handleKeyDown(kbd,e);setTimeout(()=>{keys.handleKeyUp(kbd,e);keys.handleKeyUp(kbd,s);},160);},
    reset(){touch=255;keys.handleBlur(kbd);sound.resetSound(sfx);cpu.resetMachine(machine);},
  };
  window.addEventListener('keydown',event=>{if(window.parent.rtypeCommand?.(event,true))return;window.rtype.start();keys.handleKeyDown(kbd,event);});
  window.addEventListener('keyup',event=>{if(!window.parent.rtypeCommand?.(event,false))keys.handleKeyUp(kbd,event);});
  window.addEventListener('blur',()=>window.rtype.release());
  window.addEventListener('pointerdown',()=>window.rtype.start());
  window.addEventListener('resize',()=>video.resizeScreen(gfx));
  requestAnimationFrame(frame);
  notify('rtype-ready');
}
boot().catch(error=>{
  console.error(error);
  const message='TSRun could not start. '+error.message;
  document.getElementById('error').hidden=false;document.getElementById('error').textContent=message;
  notify('rtype-error',message);
});
